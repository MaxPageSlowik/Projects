﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TetrisLibrary;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace TetrisGame
{
    public class BoardSprite : DrawableGameComponent
    {
        private IBoard board;
        private Game game;
        private SpriteBatch spriteBatch;

        //render
        private Texture2D emptyBlock;
        private Texture2D filledBlock;

        public BoardSprite(Game game, IBoard board) : base(game)
        {
            this.game = game;
            this.board = board;
        }

        public override void Initialize()
        {
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            emptyBlock = game.Content.Load<Texture2D>("EmptyBlock");
            filledBlock = game.Content.Load<Texture2D>("FilledBlock");

            base.LoadContent();
        }
        public override void Update(GameTime gameTime)
        {

            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            for (int i = 0; i <= board.Width; i++)
            {
                for (int j = 0; j <= board.Height; j++)
                {
                    //spriteBatch.Draw(emptyBlock, new Rectangle(i - 10, j - 10, 10, 10), Color.White);
                    //spriteBatch.Draw(emptyBlock, new Vector2((i)*emptyBlock.Width, (j)*emptyBlock.Width), Color.White);
                    if (board[i,j].Equals(Color.White))
                    spriteBatch.Draw(emptyBlock, new Vector2((i) * emptyBlock.Width, (j) * emptyBlock.Width),board[i,j]);
                    else
                    spriteBatch.Draw(filledBlock, new Vector2((i) * emptyBlock.Width, (j) * emptyBlock.Width), board[i, j]);

                }
                
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }
       
    }
}
