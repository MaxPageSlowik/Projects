﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TetrisLibrary;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace TetrisGame
{
    public class ShapeSprite : DrawableGameComponent
    {
        private IShape shape;

        // move down freq.
        private Score score;
        private int counterMoveDown;

        //keyboard inpt.
        private KeyboardState oldState;
        private int counterInput, treshold;

        private IBoard board;
        private Game game;
        private SpriteBatch spriteBatch;
        private int counter;
        private int threshold;
        private int downThreshold;
        private int downCounter;
        //render
        private Texture2D filledBlock;

        public ShapeSprite(Game game, IBoard board, Score score) : base(game)
        {
            this.game = game;
            this.shape = board.Shape;
            this.board = board;
            this.score = score;
        }

        public override void Initialize()
        {
            oldState = Keyboard.GetState();
            threshold = 6;
            downThreshold = 30;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            filledBlock = game.Content.Load<Texture2D>("FilledBlock");
            
            base.LoadContent();
        }

        public override void Update(GameTime gameTime)
        {
            
            if (downThreshold - score.Level < downCounter)
            {
                downCounter = 0;
                // do somthing if returns false.
                board.Shape.Drop();// when it touches the bottom, it returns false...
            }
            else
            {
                downCounter++;
            }

            // if gets to the bottom, spawn a new piece and 
            checkInput();
            base.Update(gameTime);
        }

        public override void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();
            for (int i = 0; i < 4; i++ )
            {
                spriteBatch.Draw(filledBlock, new Vector2(board.Shape[i].Position.X * filledBlock.Width, board.Shape[i].Position.Y * filledBlock.Width), board.Shape[i].Colour);
            }
             
            spriteBatch.End();

            base.Draw(gameTime);
        }

        //should have something to turn off the movements of the piece and switch focus to the new piece. 
        private void checkInput()
        {
            KeyboardState newState = Keyboard.GetState();
            if (newState.IsKeyDown(Keys.Space))
            {
                
                    board.Shape.Rotate();
                
            }
            if (newState.IsKeyDown(Keys.Right))
            {
                if (!oldState.IsKeyDown(Keys.Right))
                {
                    board.Shape.MoveRight();
                    counter = 0;
                }
                else
                {
                    counter++;
                    if (counter > threshold)
                        board.Shape.MoveRight();
                }
            }
            if (newState.IsKeyDown(Keys.Left))
            {
                if (!oldState.IsKeyDown(Keys.Left))
                {
                    board.Shape.MoveLeft();
                    counter = 0;
                }
                else
                {
                    counter++;
                    if (counter > threshold)
                        board.Shape.MoveLeft();
                }
            }
            oldState = newState;
        }
    }
}
