﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    public class Board : IBoard
    {
        public event GameOverHandler GameOver;
        public event LinesClearedHandler LinesCleared;
     
        private Color[,] board;
        private IShape shape;
        private IShapeFactory shapeFactory;
        private int height;
        private int width;
       

        public Board(int width,int height)
        {
            this.height = height;
            this.width = width;
            this.board = new Color[width, height];
            setBoard(width,height);

            this.shapeFactory = new ShapeProxy(this);
            this.shape = shapeFactory.CurrentShape;
            this.shape.JoinPile += new JoinPileHandler(addToPile);
            this.GameOver += new GameOverHandler(EndGame);

           
        }

        /// <summary>
        /// This method will initially set the board to be all black receiving the heigth and
        /// widht of the board.
        /// </summary>
        /// <param name="w"></param>
        /// <param name="h"></param>
        private void setBoard(int w,int h)
        {
            for(int i =0;i<w; i++)
            {
                for (int j = 0; j <h; j++) {
                    board[i, j] = Color.White;
                }

            }
        }
        
        /// <summary>
        /// This method is the handler to clear the lines.
        /// </summary>
        /// <param name="lines"></param>
        public void OnLinesCleared(int lines) {
            if (LinesCleared != null)
                LinesCleared(lines);
           
        }
        /// <summary>
        /// This Method ends the game.
        /// </summary>
        public void OnGameOver() {
            if (GameOver != null)
                GameOver();
        }
       
        /// <summary>
        /// This method will add the shape to the pile of shapes.
        /// </summary>
        /// <param name="shape"></param>
        private void addToPile(IShape shape)
        {
            // Color the part of the page where the shape will be.
            for (int i =0; i < shape.Length; i++)
            {
                board[shape[i].Position.X, shape[i].Position.Y] = shape[i].Colour;

            }
            //check for full lines
            OnLinesCleared(ClearLines());

            shapeFactory = new ShapeProxy(this);
            this.shape = shapeFactory.CurrentShape;
            gameOver();

        }
        /// <summary>
        /// This method terminates the game completely.
        /// </summary>
        private void EndGame()
        {
            //this.shape.JoinPile -= addToPile;
            Environment.Exit(-1);

        }
        /// <summary>
        /// This method determines if the game is over or not.
        /// </summary>
        private void gameOver()
        {
            if (!IsPlaceble())
            {
                OnGameOver();
                return;
            }

            this.shape.JoinPile += new JoinPileHandler(addToPile);
        }
        /// <summary>
        /// This method checks if there is a possibility
        /// to place more pieces in the board.
        /// </summary>
        /// <returns></returns>
        private bool IsPlaceble()
        {
            for (int i = 0; i < shape.Length; i++)
            {
                if (board[shape[i].Position.X, shape[i].Position.Y] != Color.White)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// This method takes the line that is supposed to be cleared and color it black
        /// to create the impression that was cleared.
        /// </summary>
        private int ClearLines()
        {
            int lines = 0;

            // Trying for every line and clearing them and incrementing if it is able to
            for (int i = board.GetLength(1) - 1; i > 0; i--)
            {
                if (TryClearLine(i))
                {
                    lines++;
                    i++;
                }
            }

            return lines;
        }

        private bool TryClearLine(int y)
        {
            // Checking if all blocks in row are black
            for (int i = 0; i < board.GetLength(0); i++)
            {
                if (this[i, y] == Color.White)
                {
                    return false;
                }
            }

            // put the rows down
            for (int i = 0; i < board.GetLength(0); i++)
            {
                for (int j = y; j > 0; j--)
                {
                    this[i, j] = this[i, j - 1];
                }
            }

            return true;
        }

        /// <summary>
        /// It gets the position of a block given x,y position.
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <returns>Color of block on i, j</returns>
        public Color this[int i, int j]
        {
            get
            {
                return board[i, j];
            }
            private set
            {
                board[i, j] = value;
            }
        }
       
        /// <summary>
        /// The Shape placed in the board.
        /// </summary>
        public IShape Shape
        {
            get
            {
                return shape;
            }
        }
        /// <summary>
        /// The width od the board.
        /// </summary>
        public int Width
        {
            get { return this.width-1; }
            //private set;
        }
        /// <summary>
        /// The height of the board.
        /// </summary>
        public int Height
        {
            get { return this.height-1;}
            //private set;
        }


        /// <summary>
        /// The method will get the length of the dimension of the board.
        /// </summary>
        /// <param name="rank"></param>
        /// <returns>length of dimension</returns>
        public int GetLength(int rank)
        {
            if (rank >= 1)
                return board.GetLength(rank);
            else
                return board.GetLength(0);
        }

        
    }
}
