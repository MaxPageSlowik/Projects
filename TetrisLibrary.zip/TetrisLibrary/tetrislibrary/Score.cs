﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    public class Score
    {
        private int level = 0;
        private int lines = 0;
        private int scores;

        private Board board;

        public Score(Board board, int level)
        {
            this.level = level;
            this.scores = 0;
            this.board = board;
            this.board.LinesCleared += IncrementLinesCleared;
        }

        /// <summary>
        /// The level of the game.
        /// </summary>
        public int Level
        {
            get {
                return level; 
            }
        }

        public int Lines
        {
            get { return lines; }
        }

        /// <summary>
        /// The score of the player.
        /// </summary>
        public int Scores
        {
            get {
                return scores;
            }
        }
        /// <summary>
        /// public for testing. Increment the lines cleared.
        /// </summary>
        /// <param name="num"></param>
        public void IncrementLinesCleared(int num)
        {
            lines += num;
            scores += num * num;

            level = Math.Min(lines / 10 + 1, 10);
        }
    }
}
