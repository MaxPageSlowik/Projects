﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    public class ShapeZ :Shape
    {
        private Point initialPoint;
        public ShapeZ(Point p, IBoard board) : base(board)
        {
            initialPoint = p;
            blocks[0] = new Block(p.X, p.Y, Color.Pink, board);
            blocks[1] = new Block(p.X + 1, p.Y, Color.Pink, board);
            blocks[2] = new Block(p.X + 1, p.Y + 1, Color.Pink, board);
            blocks[3] = new Block(p.X + 2, p.Y + 1, Color.Pink, board);
            currentRotation = 1;
            rotationOffset = new Point[2][];
            rotationOffset[1] = new Point[4] { new Point(1, 0), new Point(0, 1), new Point(-1, 0), new Point(-2, 1) };
            rotationOffset[0] = new Point[4] { new Point(-1, 0), new Point(0, -1), new Point(1, 0), new Point(2, -1) };



        }

            public override void Rotate()
        {
            int i = 0;
            foreach (Block b in blocks)
            {
                if (i < 4)
                if (!b.TryRotate(rotationOffset[currentRotation][i]))
                    return;
                i++;
            }
            if (currentRotation == 0)
            {
                i = 0;
                foreach (Block b in blocks)
                {
                    if (i < 4)
                    b.Rotate(rotationOffset[currentRotation][i]);
                    i++;

                }
                currentRotation = 1;
            }
            else if (currentRotation == 1)
            {
                i = 0;
                foreach (Block b in blocks)
                {
                    if (i < 4)
                    b.Rotate(rotationOffset[currentRotation][i]);
                    i++;
                }
                currentRotation = 0;
            }

        }
        public override void Reset()
        {
            blocks[0].Position = new Point(initialPoint.X, initialPoint.Y);
            blocks[1].Position = new Point(initialPoint.X + 1, initialPoint.Y);
            blocks[2].Position = new Point(initialPoint.X + 1, initialPoint.Y + 1);
            blocks[3].Position = new Point(initialPoint.X + 2, initialPoint.Y + 1);
        }
    }
}
