﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    public interface IBoard
    {
        IShape Shape { get; }

        Color this[int i,int j] { get; }
        int Width { get; }
        int Height { get; }
         

        int GetLength(int rank);
    }
}
