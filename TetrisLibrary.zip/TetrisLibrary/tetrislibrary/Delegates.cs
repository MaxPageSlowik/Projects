﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    public delegate void JoinPileHandler(IShape shape);
    public delegate void GameOverHandler();
    public delegate void LinesClearedHandler(int lines);
    class Delegates
    {
    }
}
