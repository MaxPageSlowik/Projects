﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TetrisLibrary;
using System.Drawing;

namespace TetrisTest
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    [TestClass]
    public class TestBoard
    {

        /// <summary>
        /// This test case is to ensure that whenever I ask the color from a piece in board
        /// it should return that color. Tests the whole purpose of the board and functionality.
        /// </summary>
        [TestMethod]
        public void GetColor_PropertyTest()
        {
            //instantiate
            IBoard boardTest = new Board(10,10);

            //act

            do
            {
                boardTest.Shape.Drop();
            }while (boardTest.Shape.MoveDown());

            Color shapeColor = boardTest.Shape[0].Colour;
            Color colorTest = boardTest[5, 9];
            //Assert
            Assert.AreEqual(shapeColor, colorTest);

        }
        /// <summary>
        /// This method ensures that whenever I ask for a shape,
        /// it should return the instance of shape in the board.
        /// and this piece is random.
        /// </summary>
        [TestMethod]
        public void GetShape_PropertyTest()
        {
            //istantiate
            IBoard boardTest = new Board(10, 10);

            //act
            IShape boardShape = boardTest.Shape;
            Color[] colorShapes = {Color.Green, Color.Red, Color.LightGreen, Color.LightCyan, Color.Aqua, 
                                  Color.Yellow, Color.Pink};
            //Assert
            for (int i = 0; i < colorShapes.Length; i++)
                if (boardShape[0].Colour == colorShapes[i])
                {
                    Assert.AreEqual(boardShape[0].Colour, colorShapes[i]);
                    return;
                }
        }
        /// <summary>
        /// This Method is responsible to check if we're getting the right
        /// Length from the board.
        /// </summary>
        [TestMethod]
        public void GetLength_Test()
        {
            //istantiate
            IBoard boardTest = new Board(10, 10);
            //act
            int dimension = boardTest.GetLength(0);
            //assert
            Assert.AreEqual(10,dimension);
        }

    }
}
