﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TetrisLibrary;
using System.Drawing;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
         
            Board b = new Board(10, 20);
            do
            {
                b.Shape.Drop();
            } while (b.Shape.MoveDown());
             
            do
            {
             
                b.Shape.Drop();
            } while (b.Shape.MoveDown());


            Console.WriteLine(b.ToString());
           
        }
    }
}
