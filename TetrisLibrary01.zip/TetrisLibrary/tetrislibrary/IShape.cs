﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    public interface IShape
    {
        
        int Length { get; }

        Block this[int i] { get; set; }

        event JoinPileHandler JoinPile;

        void MoveLeft();

        void MoveRight();

        bool MoveDown();

        void Drop();

        void Rotate();

        void Reset();
    }
}
