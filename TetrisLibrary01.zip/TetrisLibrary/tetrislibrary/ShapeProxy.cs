﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>

    public class ShapeProxy : IShapeFactory, IShape
    {

        private Random random;
        private IShape current;
        private IBoard board;
       

        public event JoinPileHandler JoinPile;

        public ShapeProxy(IBoard board)
        {
            this.board = board;
            random = new Random();
            DeployNewShape();

        }
        public virtual void OnJoinPile(IShape shape)
        {
            if (JoinPile != null)
            {
                JoinPile(current);
            }
        }
        public void DeployNewShape()
        {
            RandomShapeGenerator(random.Next(0, 1));
        }
        public int Length
        {
            get
            {
                return current.Length;
            }
        }
        public IShape CurrentShape
        {
            get { return current; }
        }
        private void RandomShapeGenerator(int n)
        {
            switch (n)
            {
                case 0:
                    current = new ShapeI(new Point(board.Width / 2, 0), board);
                    break;

                case 1:
                    current = new ShapeJ(new Point(board.Width / 2, 0), board);

                    break;
                case 2:
                    current = new ShapeL(new Point(board.Width / 2, 0), board);

                    break;
                case 3:
                    current = new ShapeO(new Point(board.Width / 2, 0), board);
 
                    break;
                case 4:
                    current = new ShapeS(new Point(board.Width / 2, 0), board);

                    break;
                case 5:
                    current = new ShapeZ(new Point(board.Width / 2, 0), board);

                    break;
                case 6:
                    current = new ShapeT(new Point(board.Width / 2, 0), board);

                    break;
            }
            OnJoinPile(current);
            //current.JoinPile += OnJoinPile;
           
        }

        public Block this[int i]
        {
            get
            {
                return current[i];
            }

            set
            {
                current[i] = value;
            }
        }

        public void MoveLeft()
        {
            current.MoveLeft();
        }

        public void MoveRight()
        {
            current.MoveRight();
        }

        public bool MoveDown()
        {
            return current.MoveDown();
        }

        public void Drop()
        {
            current.Drop();
        }

        public void Rotate()
        {
            current.Rotate();
        }

        public void Reset()
        {
            current.Reset();
        }
    }
}
