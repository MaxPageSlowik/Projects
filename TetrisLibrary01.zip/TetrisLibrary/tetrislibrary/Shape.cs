﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
   public abstract class Shape : IShape
    {
        private IBoard board;
        protected Block[] blocks;
        protected Point[][] rotationOffset;
        protected int currentRotation;

        public event JoinPileHandler JoinPile;

        public Shape(IBoard board)
        {
           
            this.blocks = new Block[4];
           
            this.board = board;
            this.currentRotation = 1;
        }
        /// <summary>
        /// EVENT THAT HANDLES AND CREATES AN EVENT
        /// </summary>
        protected void OnJoinPile(IShape current) {
            if (JoinPile != null)
                JoinPile(current);
        }

        public int Length
        {
            get
            {
                return blocks.Length;
            }
        }

        public Block this[int i]
        {
            get
            {
                return blocks[i];
            }

            set
            {
                blocks[i] = value;
            }
        }

        public void MoveLeft()
        {
           foreach (Block b in blocks)
            {
                if (!b.TryMoveLeft())
                    return;
                
            }
            foreach (Block b in blocks)
            {
                b.MoveLeft();
                    

            }
        }

        public void MoveRight()
        {
            foreach (Block b in blocks)
            {
                if (!b.TryMoveRight())
                    return;

            }
            foreach (Block b in blocks)
            {
                b.MoveRight();


            }
        }

        public bool MoveDown()
        {
            foreach (Block b in blocks)
            {
                
                if (!b.TryMoveDown())
                {
                    OnJoinPile(this);
                    return false;
                }
            }
            return true;
        }

        public void Drop()
        {
            if (MoveDown())
            {
                foreach (Block b in blocks)
                {
                    b.MoveDown();
                }
            }
        }

        public virtual void Rotate()
        {
            throw new NotSupportedException("Shape cannot rotate");
        }

        public virtual void Reset()
        {
            throw new NotSupportedException("Shape cannot be reset");
        }
    }
}
