﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    public class Block
    {
        private IBoard board;
        public Color Colour;

        public Block(int x, int y, Color colour,IBoard board)

        {
            this.board = board;
            this.Position = new Point(x, y);
            Colour = colour;

        }

       
        public Point Position { get;set; }


        public IBoard getBoard()
        {
            return board;
        }
        public bool TryMoveLeft()
        {
            if (Position.X-1 < 0 || !board[Position.X-1, Position.Y ].Equals(Color.Black))
                return false;
            else
                return true;
        }
        public bool TryMoveRight()
        {
            if (Position.X+1 > board.Width || !board[Position.X+1, Position.Y ].Equals(Color.Black))
                return false;
            else
                return true;
        }
        public bool TryMoveDown()
        {
            if (Position.Y+1 > board.Height || !board[Position.X,Position.Y+1].Equals(Color.Black))
                return false;
            
            else
                return true;
        }
        public bool TryRotate(Point offset)
        {
           
                if (this.Position.X + offset.X <= 0 || !board[Position.X+offset.X,Position.Y+offset.Y].Equals(Color.Black) ||this.Position.Y + offset.Y <= 0 |
                this.Position.X + offset.X >= board.Width || this.Position.Y+ offset.Y >= board.Height)
                    return false;
                else
                    return true;
            
        }
        public void MoveLeft()
        {
                    if(this.TryMoveLeft())
                Position = new Point(Position.X - 1, Position.Y);
        }
        public void MoveRight()
        {
                     if (this.TryMoveRight())
                Position = new Point(Position.X + 1, Position.Y);
        }
        public void MoveDown()
        {
                     if (this.TryMoveDown())
                Position = new Point(Position.X, Position.Y + 1);
        }
        public void Rotate(Point offset)
        {
                    if (this.TryRotate(offset))
                Position = new Point(this.Position.X + offset.X, this.Position.Y + offset.Y);
        }


    }
}
