﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    public class Board : IBoard
    {
        public event GameOverHandler GameOver;
        public event LinesClearedHandler LinesCleared;
     
        private Color[,] board;
        private IShape shape;
        private IShapeFactory shapeFactory;
        private int height;
        private int width;
       

        public Board(int width,int height)
        {
            this.height = height;
            this.width = width;
            this.board = new Color[width, height];
            setBoard(width,height);

            this.shapeFactory = new ShapeProxy(this);
            this.shape = shapeFactory.CurrentShape;
            this.shape.JoinPile += new JoinPileHandler(addToPile);
           
        }

        /// <summary>
        /// This method will initially set the board to be all black receiving the heigth and
        /// widht of the board.
        /// </summary>
        /// <param name="w"></param>
        /// <param name="h"></param>
        private void setBoard(int w,int h)
        {
            for(int i =0;i<w; i++)
            {
                for (int j = 0; j <h; j++) {
                    board[i, j] = Color.Black;
                }

            }
        }
        
        /// <summary>
        /// This method is the handler to clear the lines.
        /// </summary>
        /// <param name="lines"></param>
        public void OnLinesCleared(int lines) {
            if (LinesCleared != null)
                LinesCleared(lines);
           
        }
        /// <summary>
        /// This Method ends the game.
        /// </summary>
        public void OnGameOver() {
            if (GameOver != null)
                GameOver();
        }
       
        /// <summary>
        /// This method will add the shape to the pile of shapes.
        /// </summary>
        /// <param name="shape"></param>
        private void addToPile(IShape shape)
        {
            // Color the part of the page where the shape will be.
            for (int i =0; i < shape.Length; i++)
            {
                board[shape[i].Position.X, shape[i].Position.Y] = shape[i].Colour;

            }
            //check for full lines
            checkFullLines();

            shapeFactory = new ShapeProxy(this);
            this.shape = shapeFactory.CurrentShape;

            gameOver();

        }
        private void checkFullLines()
        {
            int counter = 0;
            //check for full lines
            for (int y = this.Height - 1; y >= 0; y--)
            {
                for (int x = this.Width - 1; x >= 0; x--)
                {
                    if (this[x, y] != Color.Black)// if the block is colored, count it.
                        counter++;
                }
                if (counter == this.Width)// if the whole line is colored, then clear it.
                {
                    OnLinesCleared(1);// fire the event.
                    ClearLine(y);// put the whole line black.
                    MovePiecesDown(y);// move this black line on top of all colored ones.
                }
                counter = 0;// put the counter at 0 again and restart it.

            }
        }

        private void gameOver()
        {
            bool placeable = true;

            for (int i = 0; i < shape.Length; i++)
            {
                if (board[shape[i].Position.X, shape[i].Position.Y] != Color.Black)
                {
                    placeable = false;
                }
            }

            if (!placeable)
            {
                OnGameOver();
            }
        }
        /// <summary>
        /// This method takes the line that is supposed to be cleared and color it black
        /// to create the impression that was cleared.
        /// </summary>
        /// <param name="line"></param>
        private void ClearLine(int line)
        {
            for (int x = this.Width - 1; x >= 0; x--)
            {
                this[x, line] = Color.Black;
            }
        }

        /// <summary>
        /// This Piece of code is moving the blocks down having a starting point the line that was
        /// just cleared. 
        /// </summary>
        /// <param name="lineCleared"></param>
        private void MovePiecesDown(int lineCleared)
        {
            int lineOnTop = 0;

            Color temp;
            for (int currentLine = lineCleared; currentLine >= 0; currentLine--)
            {
                for (int x = this.Width - 1; x >= 0; x--)
                {
                    lineOnTop = currentLine - 1;
                    if (lineOnTop < 0)
                        lineOnTop = 0;

                    // this line of code is moving up the line cleared and moving down the colored lines.
                    temp = this[x, currentLine];//temp will keep the color of the square of that position.
                    this[x, currentLine] = this[x, lineOnTop];//swap the color of the currentLine square with the correspondent on top.
                    this[x, lineOnTop] = temp;//assing the color of what was previously on the currentLine to the line on top.
                }
            }

        }
        /// <summary>
        /// It gets the position of a block given x,y position.
        /// </summary>
        /// <param name="i"></param>
        /// <param name="j"></param>
        /// <returns>Color of block on i, j</returns>
        public Color this[int i, int j]
        {
            get
            {
                return board[i, j];
            }
            private set
            {
                board[i, j] = value;
            }
        }
       
        /// <summary>
        /// The Shape placed in the board.
        /// </summary>
        public IShape Shape
        {
            get
            {
                return shape;
            }
        }
        /// <summary>
        /// The width od the board.
        /// </summary>
        public int Width
        {
            get { return this.width-1; }
            //private set;
        }
        /// <summary>
        /// The height of the board.
        /// </summary>
        public int Height
        {
            get { return this.height-1;}
            //private set;
        }


        /// <summary>
        /// The method will get the length of the dimension of the board.
        /// </summary>
        /// <param name="rank"></param>
        /// <returns>length of dimension</returns>
        public int GetLength(int rank)
        {
            if (rank >= 1)
                return board.GetLength(rank);
            else
                return board.GetLength(0);
        }

        
    }
}
