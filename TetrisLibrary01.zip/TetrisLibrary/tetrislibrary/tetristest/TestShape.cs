﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TetrisLibrary;
using System.Drawing;

namespace TetrisTest
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    [TestClass]
    public class TestShape
    {
        [TestMethod]
        // This method tests if the shape moves left
        public void TestMoveLeft_Space()
        {
            //construct
            Shape i = new ShapeI(new Point(5,0),new Board(10,10));
            Shape i1 = new ShapeI(new Point(4, 0), new Board(10,10));
            //act
            i.MoveLeft();
            //assert
            
            Assert.AreEqual(i1[0].Position, i[0].Position);
        }
        [TestMethod]
        //This method test if it moves totally left without breaking the wall.
        public void TestMoveLeft_NoSpace()
        {
            //construct
            Shape i = new ShapeI(new Point(0, 0), new Board(10, 10));
            Shape i1 = new ShapeI(new Point(0, 0), new Board(10, 10));
            //act
            i.MoveLeft();
            //assert
           
            Assert.AreEqual(i1[0].Position, i[0].Position);
        }
        [TestMethod]
        // This method tests if the shape moves right
        public void TestMoveRight_Space()
        {
            //construct
            Shape i = new ShapeI(new Point(4, 0), new Board(10, 10));
            Shape i1 = new ShapeI(new Point(5, 0), new Board(10, 10));
            //act
            i.MoveRight();
            //assert
            
            Assert.AreEqual(i1[0].Position, i[0].Position);
        }
        [TestMethod]
        // This method tests if the shape moves right without breaking the wall
        public void TestMoveRight_NoSpace()
        {
            //construct
            Shape i = new ShapeI(new Point(10, 10), new Board(10, 10));
            Shape i1 = new ShapeI(new Point(10, 10), new Board(10, 10));
            //act
            i.MoveRight();
            //assert
            
            Assert.AreEqual(i1[0].Position, i[0].Position);
        }
        [TestMethod]
        // This method tests if the shape moves down
        public void TestMoveDown()
        {
            Shape i = new ShapeI(new Point(5, 0), new Board(10, 10));
            
            //act
            bool works = i.MoveDown();
            //assert

            Assert.IsTrue(works);
        }
        [TestMethod]
        //This method tests if the shape drops completely
        public void TestDrop()
        {
            //construct
            Shape i = new ShapeI(new Point(5, 0), new Board(10, 10));
            Shape i1 = new ShapeI(new Point(5, 1), new Board(10, 10));
            //act
            i.Drop();
            //assert

            Assert.AreEqual(i1[0].Position, i[0].Position);
        }
        [TestMethod]
        //This method tests if the shape makes a single 90 degree rotation
        public void TestRotate_90Degree()
        {
            //construct
            Shape i = new ShapeI(new Point(5, 0), new Board(10, 10));
            Shape i1 = new ShapeI(new Point(5, 0), new Board(10, 10));
            //act
            i.Rotate();
            i1.Rotate();
            //assert

            Assert.AreEqual(i1[3].Position, i[3].Position);
        }
       
       
        [TestMethod]
        //ask teache what Reset does.
        public void TestReset()
        {
            //construct
            Shape i = new ShapeI(new Point(5, 0), new Board(10,10));
            Shape i1 = new ShapeI(new Point(5, 0), new Board(10,10));
            //act
            i.Rotate();
            i.Reset();
            //assert

            Assert.AreEqual(i1[3].Position, i[3].Position);
        }
    }
}
