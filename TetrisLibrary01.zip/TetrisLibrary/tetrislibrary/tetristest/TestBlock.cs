﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using TetrisLibrary;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TetrisTest
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    [TestClass]
    public class TestBlock
    {
        [TestMethod]
        //This method will try to move the block left
        // if it returns true, it will move.
        public void TestTryMoveLeft_TrueCase()
        {
            Block block = new Block(1, 1, Color.Aqua, new Board(10,10));

            bool movedLeft = block.TryMoveLeft();

            Assert.IsTrue(movedLeft,"The block can move left");
        }
        [TestMethod]
        //This method will try to move the block left.
        // inverse of the first.
        public void TestTryMoveLeft_FalseCase()
        {
            Block block = new Block(0, 0, Color.Aqua, new Board(10,10));

            bool movedLeft = block.TryMoveLeft();

            Assert.IsFalse(movedLeft,"The block cannot move left anymore");
        }
        [TestMethod]
        //This method will try to move the block right.
        public void TestTryMoveRight_TrueCase()
        {
            Block block = new Block(1, 1, Color.Aqua, new Board(10,10));

            bool movedRight = block.TryMoveRight();

            Assert.IsTrue(movedRight, "The block can move right");
        }

        [TestMethod]
        //This method will try to move the block right.
        // inverse of the first.
        public void TestTryMoveRight_FalseCase()
        {
            Block block = new Block(10, 10, Color.Aqua, new Board(10,10));

            bool movedRight = block.TryMoveRight();

            Assert.IsFalse(movedRight, "The block cannot move right");
        }
        [TestMethod]
        //This method will try to move the block Down
        public void TestTryMoveDown_TrueCase()
        {
            Block block = new Block(1, 1, Color.Aqua, new Board(10,10));
            bool movedDown = block.TryMoveRight();

            Assert.IsTrue(movedDown, "The block can move down");
        }

        [TestMethod]
        //This method will try to move the block down and doesn't move down
        public void TestTryMoveDown_FlaseCase()
        {
            Block block = new Block(0, 10, Color.Aqua, new Board(10,10));
            bool movedDown = block.TryMoveDown();

            Assert.IsFalse(movedDown, "The block cannot move right");
        }
        [TestMethod]
        public void TestTryRotate_TrueCase()
        {
            Block block = new Block(1, 1, Color.Aqua, new Board(10,10));
            bool rotated = block.TryRotate(new Point(1,2));
            Assert.IsTrue(rotated, "The block cannot rotate");

        }
        [TestMethod]
        public void TestTryRotate_FalseCase()
        {
            Block block = new Block(9, 9, Color.Aqua, new Board(10,10));
            Block block2 = new Block(10, 10, Color.Aqua, new Board(10,10));
            bool rotated = block.TryRotate(new Point(1, 1));
            Assert.IsFalse(rotated, "The block cannot rotate");
        }
        [TestMethod]
        public void TestMoveLeft_Space()
        {
            Block block = new Block(2, 0, Color.Aqua, new Board(10,10));
            Block block2 = new Block(0, 0, Color.Aqua, new Board(10,10));

            block.MoveLeft();
            //block.MoveLeft();
            Assert.AreNotEqual(block2.Position, block.Position);
        }
        [TestMethod]
        public void TestMoveLeft_NoSpace()
        {
            Block block = new Block(0, 0, Color.Aqua, new Board(10,10));
            Block block2 = new Block(0, 0, Color.Aqua, new Board(10,10));

            block.MoveLeft();
           
           
            Assert.AreEqual(block2.Position,block.Position);
        }
        [TestMethod]
        public void TestMoveRight_Space()
        {
            Block block = new Block(0, 0, Color.Aqua, new Board(10,10));
            Block block2 = new Block(2, 0, Color.Aqua, new Board(10,10));

            block.MoveRight();
            block.MoveRight();
            Assert.AreEqual(block2.Position, block.Position);
        }
        [TestMethod]
        public void TestMoveRight_NoSpace()
        {
            Block block = new Block(10, 0, Color.Aqua, new Board(10,10));
            Block block2 = new Block(10, 0, Color.Aqua, new Board(10,10));

            block.MoveRight();


            Assert.AreEqual(block2.Position, block.Position);
        }
        [TestMethod]
        public void TestMoveDown_Space()
        {
            Block block = new Block(1, 0, Color.Aqua, new Board(10,10));
            Block block2 = new Block(1, 1, Color.Aqua, new Board(10,10));

            block.MoveDown();


            Assert.AreEqual(block2.Position, block.Position);
        }
        [TestMethod]
        public void TestMoveDown_NoSpace()
        {
            Block block = new Block(10, 10, Color.Aqua, new Board(10,10));
            Block block2 = new Block(10, 10, Color.Aqua, new Board(10,10));

            block.MoveDown();


            Assert.AreEqual(block2.Position, block.Position);
        }
        [TestMethod]
        public void TestRotate_Space()
        {
            Block block = new Block(1, 1, Color.Aqua, new Board(10,10));
            Block block2 = new Block(2, 2, Color.Aqua, new Board(10,10));

            block.Rotate(new Point(1,1));


            Assert.AreEqual(block2.Position, block.Position);
        }
        [TestMethod]
        public void TestRotate_NoSpace()
        {
            Block block = new Block(10, 10, Color.Aqua, new Board(10,10));
            Block block2 = new Block(10, 10, Color.Aqua, new Board(10,10));

            block.Rotate(new Point(1,1));


            Assert.AreEqual(block2.Position, block.Position);
        }
    }
}
