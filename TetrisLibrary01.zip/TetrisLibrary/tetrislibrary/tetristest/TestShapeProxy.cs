﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TetrisLibrary;
using System.Drawing;




namespace TetrisTest
{
    /// <summary>
    /// ShapeProxy is a facade for Shape class.
    /// We will be testing only the different methods in.
    /// The ones that are the same in the shape are being tested in the Shape.
    /// Also The DeployNewShape is being tested during the Board tests.
    /// Test unit class.
    /// </summary>
    [TestClass]
    public class TestShapeProxy
    {
    }
}
