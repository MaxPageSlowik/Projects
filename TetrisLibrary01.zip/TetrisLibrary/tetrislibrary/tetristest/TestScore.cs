﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TetrisLibrary;

namespace TetrisTest
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    [TestClass]
    public class TestScore
    {
        [TestMethod]
        public void Test_IncrementLinesCleared_Lines()
        {
            //instantiate
            Board b = new Board(10, 10);
            Score s = new Score(b, 0);

            //act
            s.IncrementLinesCleared(1);

            //assert
            Assert.AreEqual(1, s.Lines);
        }
        [TestMethod]
        public void Test_IncrementLinesCleared_Score()
        {
            //instantiate
            Board b = new Board(10, 10);
            Score s = new Score(b, 0);

            //act
            s.IncrementLinesCleared(2);

            //assert
            Assert.AreEqual(4, s.Scores);
        }

        public void Test_IncrementLinesCleared_Level()
        {
            //instantiate
            Board b = new Board(10, 10);
            Score s = new Score(b, 0);

            //act
            s.IncrementLinesCleared(2);

            //assert
            Assert.AreEqual(1, s.Level);

        }
    }
}
