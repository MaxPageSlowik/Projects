﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
namespace TetrisLibrary
{
    /// <summary>
    /// Author: Ryan Sena & Max Page.
    /// </summary>
    class ShapeO :Shape
    {
        private Point initialPoint;
        public ShapeO(Point p, IBoard board) : base(board)
        {
            initialPoint = p;
            blocks[0] = new Block(p.X, p.Y, Color.LightCyan, board);
            blocks[1] = new Block(p.X, p.Y+1, Color.LightCyan, board);
            blocks[2] = new Block(p.X+1, p.Y, Color.LightCyan, board);
            blocks[3] = new Block(p.X+1, p.Y+1, Color.LightCyan, board);
           

        }
        public override void Rotate()
        {
            return;
        }
        public override void Reset()
        {
            blocks[0].Position = new Point(initialPoint.X, initialPoint.Y);
            blocks[1].Position = new Point(initialPoint.X, initialPoint.Y + 1);
            blocks[2].Position = new Point(initialPoint.X + 1, initialPoint.Y);
            blocks[3].Position = new Point(initialPoint.X + 1, initialPoint.Y + 1);
        }
    }
}
