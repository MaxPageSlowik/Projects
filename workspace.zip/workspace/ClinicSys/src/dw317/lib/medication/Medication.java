// @author: 	Jonathan Bizier
// @version:	Monday, September 21, 2015

package dw317.lib.medication;

import java.io.Serializable;

public interface Medication extends Serializable {
	String getNumber();

	Scheme getScheme();

	String getName();

	// Medication factory method based on Scheme
	public static Medication getInstance(Scheme scheme, String number, String name) {
		Medication medication = null;
		switch (scheme) {
		// Creates DIN medication object
		case DIN:
			medication = new DINMedication(number, name);
			break;
		// Creates NDC medication object
		case NDC:
			medication = new NDCMedication(number, name);
		}
		return medication;
	}

	public enum Scheme {
		// Schemes for diferent types of medication numbers
		DIN("XXXXXXXX"), NDC("XXXX-XXXX-XX");

		private String format;

		private Scheme(String format) {
			this.format = format;
		}

		public String getFormat() {
			return format;
		}
	}
}
