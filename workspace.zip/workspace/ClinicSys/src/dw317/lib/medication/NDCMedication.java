// @author: 	Jonathan Bizier
// @version:	Monday, September 21, 2015

package dw317.lib.medication;

import dw317.lib.medication.Medication.Scheme;

public final class NDCMedication extends AbstractMedication {
	// Initiate variables
	private final long serialVersionUID = 42031768871L;

	// Constructor using super call and validating number
	public NDCMedication(String number, String name) {
		super(Scheme.NDC, validateNumber(number), name);

	}

	// Try-catch block to validate correct number format
	private static String validateNumber(String number) {
		// If number is null
		if (number.trim() == null) {
			throw new IllegalArgumentException(
					"Invalid NDC Number: Expected XXXXX-XXX-XX format! Got null!");
		}
		// If number is an empty string
		if (number.trim() == "") {
			throw new IllegalArgumentException(
					"Invalid NDC Number: Expected XXXXX-XXX-XX format! Got "
							+ number + "!");
		}
		// If number is smaller than desired format
		if (number.trim().length() > 12) {
			throw new IllegalArgumentException(
					"Invalid NDC Number: Expected XXXXX-XXX-XX format! Got "
							+ number + "!");
		}
		// If number is greater than desired format
		if (number.trim().length() < 12) {
			throw new IllegalArgumentException(
					"Invalid NDC Number: Expected XXXXX-XXX-XX format! Got "
							+ number + "!");
		}
		// Checking for dashes in number and making sure there is only 2
		if (number.trim().indexOf('-') == -1 || number.trim().lastIndexOf('-') == -1){
			throw new IllegalArgumentException(
					"Invalid NDC Number: Expected XXXXX-XXX-XX format! Got "
							+ number + "!");
		}
		

		// Validating number by initiating in into variables
		try{
		// Parsing into int to check if number is made of digits
		int validate = Integer.parseInt(number.substring(0, number.trim().indexOf('-')));
		validate = Integer.parseInt(number.substring(number.trim().indexOf('-'), number.trim().lastIndexOf('-')));
		validate = Integer.parseInt(number.substring(number.trim().lastIndexOf('-'), 12));
		
		} catch (IllegalArgumentException IRE) {
			// Bubbling up exception
			throw new IllegalArgumentException(IRE);
		}
		// If nothing wrong, return number as-is
		return number;
	}
}
