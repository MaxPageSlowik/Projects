// @author: 	Jonathan Bizier
// @version:	Monday, September 21, 2015

package dw317.lib.medication;

public abstract class AbstractMedication implements Medication {
	// Initiate variables
	private static final long serialVersionUID = 42031768871L;
	private final Scheme scheme;
	private final String number;
	private final String name;

	// Constructor
	public AbstractMedication(Scheme scheme, String number, String name) {
		this.scheme = scheme;
		this.number = number;
		this.name = name;
	}

	// Getter for the scheme
	@Override
	public Scheme getScheme() {
		return this.scheme;
	}

	// Getter for the number
	@Override
	public String getNumber() {
		return this.number;
	}

	// Getter for the name
	@Override
	public String getName() {
		return this.name;
	}

	// Getter for the toString()
	@Override
	public String toString() {
		return this.scheme + "*" + this.number + "*" + this.name;
	}

	// Custom equals for the object
	@Override
	public final boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (object == null) {
			return false;
		}

		if (this.getClass() != object.getClass()) {
			return false;
		}

		AbstractMedication obj = (AbstractMedication) object;

		if (this.scheme == obj.scheme) {
			return true;
		}

		if (this.number == obj.number) {
			return true;
		}
		return true;
	}

	// Custom hash code for the object
	@Override
	public final int hashCode() {
		return this.number.hashCode() + this.scheme.hashCode();
	}
}
