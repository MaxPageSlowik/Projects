// @author: 	Jonathan Bizier
// @version:	Monday, September 21, 2015

package dw317.lib.medication;

import dw317.lib.medication.Medication.Scheme;

public final class DINMedication extends AbstractMedication {
	// Initiate variables
	private final long serialVersionUID = 42031768871L;

	// Constructor using super call and validating number
	public DINMedication(String number, String name) {
		super(Scheme.DIN, validateNumber(number), name);

	}

	// Try-catch block to validate correct number format
	private static String validateNumber(String number) {
		// If number is null
		if (number.trim() == null) {
			throw new IllegalArgumentException(
					"Invalid DIN Number: Expected XXXXXXXX format! Got null!");
		}
		// If number is an empty string
		if (number.trim() == "") {
			throw new IllegalArgumentException(
					"Invalid DIN Number: Expected XXXXXXXX format! Got "
							+ number + "!");
		}
		// If number is smaller than desired format
		if (number.trim().length() > 8) {
			throw new IllegalArgumentException(
					"Invalid DIN Number: Expected XXXXXXXX format! Got "
							+ number + "!");
		}
		// If number is greater than desired format
		if (number.trim().length() < 8) {
			throw new IllegalArgumentException(
					"Invalid DIN Number: Expected XXXXXXXX format! Got "
							+ number + "!");
		}
		
		// Validation for the number
		try {
			// Parsing into int to check if number is made of digits
			int validate = Integer.parseInt(number);
		} catch (IllegalArgumentException IRE) {
			// Bubbling up exception
			throw new IllegalArgumentException(IRE);
		}
		
		// If nothing wrong, return number as-is
		return number;
	}
}
