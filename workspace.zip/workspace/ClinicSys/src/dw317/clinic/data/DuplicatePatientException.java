package dw317.clinic.data;

public class DuplicatePatientException extends Exception {
	private static final long serialVersionUID = 42031768871L;

	/*
	 * Signals that the provided RAMQ exists already.
	 */
	public DuplicatePatientException(){
		super("The provided patient RAMQ already exists");
	}

	public DuplicatePatientException(String s){
		super(s);
	}
}