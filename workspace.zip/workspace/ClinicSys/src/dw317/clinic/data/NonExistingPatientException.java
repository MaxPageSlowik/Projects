package dw317.clinic.data;
public class NonExistingPatientException extends Exception{
	private static final long serialVersionUID = 2756868193538823758L;
	
	/*
	 * Signals that the patient does not exist.
	 */
	public NonExistingPatientException(){
		super("Patient does not exits");
		
	}
	
	public NonExistingPatientException(String s){
		super(s);
	}

	
}