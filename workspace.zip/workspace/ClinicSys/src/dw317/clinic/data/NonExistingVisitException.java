package dw317.clinic.data;

public class NonExistingVisitException extends Exception {
	private static final long serialVersionUID = 3424103762258587686L;
	/*
	 * Signals that the visit does not exist.
	 */
	public NonExistingVisitException(){
		super("Visit does not exist");
	}
	
	public NonExistingVisitException(String s){
		super (s);
	}

}
