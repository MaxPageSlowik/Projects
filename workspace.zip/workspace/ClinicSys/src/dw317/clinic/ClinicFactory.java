package dw317.clinic;

import dw317.clinic.business.interfaces.PatientVisitFactory;
import dw317.clinic.business.interfaces.PriorityPolicy;
import dw317.clinic.data.interfaces.VisitDAO;

import java.io.Serializable;

public interface ClinicFactory extends Serializable {
	PatientVisitFactory getPatientVisitFactory();
	PriorityPolicy getPriorityPolicyInstance(VisitDAO visistConnection);
}

