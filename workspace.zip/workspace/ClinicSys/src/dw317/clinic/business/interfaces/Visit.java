package dw317.clinic.business.interfaces;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Optional;
import group3.clinic.business.Priority;

/**
 * interface that implements the ClinicVisit.java class
 * 
 * @author
 *
 */
public interface Visit extends Comparable<Visit>, Serializable {

	public Patient getPatient();

	public LocalDateTime getRegistrationDateAndTime();

	public Priority getPriority();

	public String getComplaint();
	
	public Optional<LocalDateTime> getTirageDateAndTime();

	public void setRegistrationDateAndTime(int year, int month, int day, int hour, int minute);

	public void setRegistrationDateAndTime(Optional<LocalDateTime> datetime);

	public void setTriageDateAndTime(int year, int month, int day, int hour, int minute);

	public void setTriageDateAndTime(Optional<LocalDateTime> datetime);

	public void setPriority(Priority aPriority);

	public void setComplaint(Optional<String> complaint);

}
