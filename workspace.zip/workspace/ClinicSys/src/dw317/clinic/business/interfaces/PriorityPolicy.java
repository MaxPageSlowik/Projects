/**
 * 
 */
package dw317.clinic.business.interfaces;
import java.io.Serializable;
import java.util.Optional;

/**
 * @author Max
 *
 */
public interface PriorityPolicy extends Serializable{
	/**
	 * Returns the next visit of the next patient that must be examined.
	 *
	 * @return  The visit of the next patient that must be examined.
	 */
	Optional<Visit> getNextVisit();

}
