package dw317.clinic.business.interfaces;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Optional;

import dw317.lib.Name;
import dw317.lib.medication.Medication;
import group3.clinic.business.Ramq;

/**
 * Interface method, implementing methods are: the ClinicPatient.java class
 * 
 * @author
 *
 */
public interface Patient extends Comparable<Patient>, Serializable {
	public Name getName();

	public Ramq getRamq();

	public LocalDate getBirthday();

	public String getTelephoneNumber();

	public Optional<Medication> getMedication();

	public String getExistingConditions();

	public void setTelephoneNumber(Optional<String> telephoneNumber);

	public void setMedication(Optional<Medication> medication);

	public void setExistingConditions(Optional<String> ailment);

}
