/**
 * 
 */
package group3.dawsonclinic;

import java.util.Optional;

import dw317.clinic.business.interfaces.PriorityPolicy;
import dw317.clinic.business.interfaces.Visit;
import dw317.clinic.data.interfaces.VisitDAO;
import group3.clinic.business.Priority;

/**
 * @author Max
 *
 */
public class DawsonClinicPriorityPolicy implements PriorityPolicy{
	private static final long serialVersionUID = 42031768871L;
	private VisitDAO visitDB;
	private int counter = 1;
	public DawsonClinicPriorityPolicy(VisitDAO visitDB){
		this.visitDB = visitDB;
	}
	/**
	 * Get's the next visit in the database, based off the priority code
	 * removes the visit from the database and returns it.
	 * @return the optional visit object from the list of queues
	 * Cycles through in the specified order of
	 * Priority 1 are always first no matter what then
	 * Priority 2 are 1st, 3rd, 6th, and 8th then 
	 * Priority 3 are 2nd, 5th, and 9th then
	 * Priority 4 are 4th, and 10th then
	 * Priority 5 is 7th
	 */
	@Override
	public Optional<Visit> getNextVisit() {
		Optional<Visit> visit;
		int visitCounter = 0;
		while(visitCounter<=10){
		if(visitDB.getNextVisit(Priority.REANIMATION).isPresent()){
			visit = visitDB.getNextVisit(Priority.REANIMATION);
			visitDB.remove(Priority.REANIMATION);
			return visit;
		}
		else if (visitDB.getNextVisit(Priority.VERYURGENT).isPresent() && 
				(counter == 1 || counter == 3 || counter == 6 || counter == 8))
			{
			counter++;
			visit = visitDB.getNextVisit(Priority.VERYURGENT);
			visitDB.remove(Priority.VERYURGENT);
			return visit;
			
		}
		else if (visitDB.getNextVisit(Priority.URGENT).isPresent() &&
				(counter == 2 || counter == 5 || counter == 9)){
			counter++;
			visit = visitDB.getNextVisit(Priority.URGENT);
			visitDB.remove(Priority.URGENT);
			return visit;
		}
		else if(visitDB.getNextVisit(Priority.LESSURGENT).isPresent() &&
				(counter == 4 || counter == 10))
		{
			counter++;
			visit = visitDB.getNextVisit(Priority.LESSURGENT);
			visitDB.remove(Priority.LESSURGENT);
			return visit;	
		}
		else if(visitDB.getNextVisit(Priority.NOTURGENT).isPresent() &&
				(counter == 7)){
			counter++;
			visit = visitDB.getNextVisit(Priority.NOTURGENT);
			visitDB.remove(Priority.NOTURGENT);
			return visit;	
		}
		else
			counter++;
			visitCounter++;
			if(counter > 10)
				counter = 1;
			
			
			
	}
				return Optional.of(null);	
			
		
	}

}
