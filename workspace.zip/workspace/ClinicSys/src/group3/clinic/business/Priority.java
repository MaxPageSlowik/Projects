package group3.clinic.business;

/**
 * Priority enum, returns the priority number based on the corresponding enum
 * which is based on the visit.txt
 * 
 * @author Evan
 *
 */
public enum Priority {
	NOTASSIGNED(0), REANIMATION(1), VERYURGENT(2), URGENT(3), LESSURGENT(4), NOTURGENT(5);

	private int code;

	/**
	 * sets code variable.
	 * 
	 * @param code
	 */
	private Priority(int code) {
		this.code = code;
	}

	/**
	 * returns code
	 * 
	 * @return int code
	 */
	public int getCode() {
		return this.code;
	}
}
