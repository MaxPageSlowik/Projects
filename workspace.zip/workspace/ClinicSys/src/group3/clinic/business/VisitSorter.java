package group3.clinic.business;
import java.util.Comparator;
import dw317.clinic.business.interfaces.Visit;

/**
 * @author Evan Glickakis
 *
 */
public class VisitSorter implements Comparator<Visit> {
	/**
	 * 
	 * @param Visist 1, Visit2
	 * @return An int representing the difference between 2 visits
	 */
	@Override
	public int compare(Visit v1, Visit v2){
		if (v1.equals(v2))
			return 0;
		if(v1.getPriority() != v2.getPriority())
			return v1.getPriority().compareTo(v2.getPriority());
		
		return v1.compareTo(v2);
	}
}