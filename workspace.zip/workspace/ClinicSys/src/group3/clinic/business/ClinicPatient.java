package group3.clinic.business;

import java.time.LocalDate;
import java.util.Optional;

import dw317.clinic.business.interfaces.Patient;
import dw317.lib.Name;
import dw317.lib.medication.Medication;

/**
 * @author Max Page-Slowik
 *
 */
public class ClinicPatient implements Patient {
	private static final long serialVersionUID = 42031768871L;
	private String ailment = "";
	private Medication med;
	private Name name;
	private Ramq ramq;
	private String telephoneNumber = "";

	/**
	 * Constructor for the Clinic Patient that extends Patient interface 
	 * checks the name and returns a null pointer exception if the name 
	 * is wrong.
	 * 
	 * @param firstName
	 * @param lastName
	 * @param ramq
	 * @throws NullPointerException
	 */
	public ClinicPatient(String firstName, String lastName, String ramq) {
		
			if (firstName == null & lastName == null)
				throw new IllegalArgumentException
				("Names must contain letters");
			if (firstName.length() < 2 || lastName.length() < 2)
				throw new IllegalArgumentException
				("Names must contain more than 2 characters");
			if (!isAlpha(firstName) || !isAlpha(lastName))
				throw new IllegalArgumentException
				("Names do not contain anything other than letters");
		 
		this.name = new Name(firstName, lastName);
		this.ramq = new Ramq(ramq);
		
	}

	/**
	 * @param o
	 * @return int based of the comparison between a Patient and another.
	 */
	@Override
	public int compareTo(Patient o) {
		if (o == null)
			return 1;
		if (this == o)
			return 0;
		if (this.getRamq().equals(o.getRamq()))
			return 0;
		else if (this.getName().compareTo(o.getName()) > 0)
			return 1;
		else
			return -1;
	}

	/**
	 * @param o
	 * @return final boolean deciding if the Clinic Patients are equal.
	 */
	@Override
	public final boolean equals(Object o) {
		
		if (this == o)
			return true;
		if (o == null)
			return false;
		if (o.getClass() != this.getClass())
			return false;
		ClinicPatient pat = (ClinicPatient) o;
		if (pat.getClass().equals(this.getClass()) &&
				pat.getRamq().equals(this.getRamq()))
			return true;
		return false;

	}

	/**
	 * @return the LocalDateObject of the patient's birthday.
	 */
	@Override
	public LocalDate getBirthday() {
		return this.ramq.getBirthdate();
	}

	/**
	 * @return the existing conditions of the patient.
	 */
	@Override
	public String getExistingConditions() {
		return this.ailment;

	}

	/**
	 * @return the optional Medication object.
	 */
	@Override
	public Optional<Medication> getMedication() {
		return Optional.ofNullable(med);
	}

	/**
	 * @return Deep copy of the name
	 */
	@Override
	public Name getName() {
		return new Name(this.name.getFirstName(), this.name.getLastName());
	}

	/**
	 * @return the Ramq
	 */
	@Override
	public Ramq getRamq() {
		return this.ramq;

	}

	/**
	 * @return the telephone number.
	 */
	@Override
	public String getTelephoneNumber() {
		return this.telephoneNumber;
	}

	/**
	 * @return final int hashcode of the ramq and name mixed.
	 */
	@Override
	public final int hashCode() {
		return (ramq.hashCode() + name.hashCode());
	}

	/**
	 * 
	 * @param s
	 * @return boolean to see if the string contains only letters
	 */
	public boolean isAlpha(String s) {
		char[] chars = s.toCharArray();
		for (char c : chars) {
			if (!Character.isLetter(c) && !(c == '\'') && !(c== '-') && !(c == ' '))
				return false;
		}
		return true;

	}

	/**
	 * Sets the Ailment to null or the actual ailment
	 * 
	 * @param <String>
	 *            ailment
	 */
	@Override
	public void setExistingConditions(Optional<String> ailment) {
		this.ailment = ailment.orElse("");

	}

	/**
	 * Sets the medication if there is any
	 * 
	 * @param <Medication>
	 *            medication
	 */
	@Override
	public void setMedication(Optional<Medication> medication) {
		this.med = medication.orElse(null);

	}

	/**
	 * sets the telephone number if given
	 * 
	 * @param telephoneNumber
	 */
	@Override
	public void setTelephoneNumber(Optional<String> telephoneNumber) {
		if (telephoneNumber.orElse("").length() != 10)
			throw new IllegalArgumentException("Wrong Telephone Number");
		else
			this.telephoneNumber = telephoneNumber.orElse("");

	}

	/**
	 * @return the full asterix separated string that contains the ramq, 
	 * 		   first name, last name, telephone number, medicine name,
	 * 		   Scheme and number as well as past conditions.
	 */
	@Override
	public String toString() {
		Medication meds = this.getMedication().orElse(null);
		String medName, medNum, medScheme;
		if (meds == null) {
			medName = "";
			medScheme = "";
			medNum = "";
		} else {
			medName = meds.getName();
			medScheme = "" + meds.getScheme();
			medNum = meds.getNumber();
		}
		String str = this.ramq + "*" + this.name.getFirstName() + "*" + 
		this.name.getLastName() + "*" + this.getTelephoneNumber() + 
		"*" + medScheme + "*" + medNum + "*" + medName + "*"
		+ this.getExistingConditions();
		
		return str;
	}
}
