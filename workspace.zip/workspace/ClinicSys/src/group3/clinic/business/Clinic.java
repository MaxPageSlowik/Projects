/**
 * 
 */
package group3.clinic.business;

import java.io.IOException;
import java.util.List;
import java.util.Observable;
import java.util.Optional;

import dw317.clinic.ClinicFactory;
import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.PatientVisitManager;
import dw317.clinic.business.interfaces.Visit;
import dw317.clinic.data.DuplicatePatientException;
import dw317.clinic.data.NonExistingPatientException;
import dw317.clinic.data.NonExistingVisitException;
import dw317.clinic.data.interfaces.PatientDAO;
import dw317.clinic.data.interfaces.VisitDAO;
import dw317.lib.medication.Medication;
import group3.dawsonclinic.DawsonClinicPriorityPolicy;
import group3.util.Utility;

/**
 * @author group3
 *
 */
public class Clinic extends Observable implements PatientVisitManager {

	/**
	 * 
	 */
	private static final long serialVersionUID = 42031768871L;
	private final ClinicFactory factory;
	private final PatientDAO patientConnection;
	private final VisitDAO visitConnection;

	public Clinic(PatientDAO patientConnection, VisitDAO visitConnection, ClinicFactory factory) {
		this.patientConnection = patientConnection;
		this.visitConnection = visitConnection;
		this.factory = factory;
		try {
			Utility.deserializeObject("./datafiles/database/patients.ser");
			Utility.deserializeObject("./datafiles/database/visits.ser");

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void closeClinic() throws IOException {
		patientConnection.disconnect();
		visitConnection.disconnect();
	}

	@Override
	public void createVisit(Patient patient, String complaint) {
		
		Visit v = factory.getPatientVisitFactory().getVisitInstance(patient);
		v.setComplaint(Optional.of(complaint));
		visitConnection.add(v);
		
		setChanged();
		notifyObservers(v);

	}

	@Override
	public Patient findPatient(String ramq) throws NonExistingPatientException {
		Patient p;
		if (!patientConnection.exists(new Ramq(ramq)))
			throw new NonExistingPatientException("Patient " + ramq + " does not exist");
		else
			p = patientConnection.getPatient(new Ramq(ramq));
		setChanged();
		notifyObservers(p);
		return  p;
	}

	@Override
	public List<Patient> findPatientsPrescribed(Medication meds) {
		return patientConnection.getPatientsPrescribed(meds);
	
	}

	@Override
	public Optional<Visit> nextForTriage() {
		Optional<Visit> v;

		v = visitConnection.getNextVisit(Priority.NOTASSIGNED);
		
		setChanged();
		notifyObservers(v);
		return v;
	}

	@Override
	public Optional<Visit> nextForExamination() {
		
		Optional<Visit> v;

		DawsonClinicPriorityPolicy dcpp = new DawsonClinicPriorityPolicy(visitConnection);
		v = dcpp.getNextVisit();
		setChanged();
		notifyObservers(v);
		return v;
	}

	@Override
	public void registerNewPatient(String firstName, String lastName, String ramq, String telephone, Medication meds,
			String conditions) throws DuplicatePatientException {
		Patient p;
		p = factory.getPatientVisitFactory().getPatientInstance(firstName, lastName, ramq);
		p.setTelephoneNumber(Optional.of(telephone));
		p.setMedication(Optional.of(meds));
		p.setExistingConditions(Optional.of(conditions));
		patientConnection.add(p);
		
		setChanged();
		notifyObservers(p);
		
	}

	@Override
	public void changeTriageVisitPriority(Priority newPriority) throws NonExistingVisitException {
		Optional<Visit> v;

		v = visitConnection.getNextVisit(Priority.NOTASSIGNED);
		if(v.isPresent()){
			v.orElse(null).setPriority(newPriority);
			visitConnection.add(v.orElse(null));
			visitConnection.update(Priority.NOTASSIGNED, newPriority);
		}
		
		
		setChanged();
		notifyObservers(newPriority);

	}

}
