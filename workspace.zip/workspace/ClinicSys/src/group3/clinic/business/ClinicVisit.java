/**
 * 
 */
package group3.clinic.business;

import java.time.LocalDateTime;
import java.util.Optional;
import group3.util.*;
import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.Visit;

/**
 * @author Max Page-Slowik The Clinic Visit class that extends the interface
 *         Visit in order to log a patients visit to the clinic.
 */
public class ClinicVisit implements Visit {
	private static final long serialVersionUID = 42031768871L;
	private String complaint;
	private ClinicPatient patient;
	private Priority priority;
	private LocalDateTime regTime;

	private LocalDateTime triageTime;

	/**
	 * Constructor for the Clinic visits
	 * 
	 * @param aPatient
	 */
	public ClinicVisit(Patient aPatient) {
		if (aPatient == null)
			throw new NullPointerException("A patient must exist in order for there"
					+ "to be a visit record");
		this.patient = (ClinicPatient) aPatient;
		this.priority = Priority.NOTASSIGNED;
		this.regTime = LocalDateTime.now();
		this.triageTime = null;
		this.complaint = "";
	}

	/**
	 * Overridden compareTO method to compare the the difference between two
	 * visit logs by their registration date
	 * 
	 * @param o
	 * @return an integer showing if the value of the object is greater.
	 */
	@Override
	public int compareTo(Visit o) {
		if (o == null)
			return 1;
		if (this == o)
			return 0;
		if (this.getRegistrationDateAndTime().equals(o.getRegistrationDateAndTime())){
			return this.getPatient().compareTo(o.getPatient());
		}
		
		else if (this.getRegistrationDateAndTime().compareTo(o.getRegistrationDateAndTime()) > 0 
				&& this.getPriority().compareTo(o.getPriority()) < 0)
			return 1;
		else
			return -1;
	}

	/**
	 * @param o
	 * @return the final boolean to see if two ClinicVisits are the same.
	 */
	@Override
	public final boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null)
			return false;
		if (o.getClass() != this.getClass())
			return false;
		ClinicVisit vis = (ClinicVisit) o;
		if (vis.getClass().equals(this.getClass())
				&& vis.getRegistrationDateAndTime().equals(this.getRegistrationDateAndTime()))
			return true;
		return false;

	}

	/**
	 * @return the complaint the patient is coming in for
	 */
	@Override
	public String getComplaint() {
		return this.complaint;
	}

	/**
	 * @return the Patient
	 */
	@Override
	public Patient getPatient() {
		Patient pat = this.patient;
		return (Patient)Utility.copyOf(pat);
	}

	/**
	 * @return the enum priority to see the level of priority
	 */
	@Override
	public Priority getPriority() {
		return this.priority;
	}

	/**
	 * @return the LocalDateTime set to the current time and date
	 */
	@Override
	public LocalDateTime getRegistrationDateAndTime() {
		return this.regTime;
	}

	/**
	 * @return the Optional value of triageTime
	 */
		@Override
		public Optional<LocalDateTime> getTirageDateAndTime() {
		 return Optional.ofNullable(triageTime);
		}

	/**
	 * @return the hashcode of patient and regtime mixed.
	 */
	@Override
	public final int hashCode() {
		return (this.patient.hashCode() + this.regTime.hashCode());
	}

	/**
	 * @param complaint
	 *            Sets the complaint optionally
	 */
	@Override
	public void setComplaint(Optional<String> complaint) {
		this.complaint = complaint.orElse("");

	}

	/**
	 * @param aPriority
	 *            Set the priority enum for the priority
	 */
	@Override
	public void setPriority(Priority aPriority) {
		this.priority = aPriority;
	}

	/**
	 * @param year,
	 *            month, day, hour, minute, sec Sets the registration time and
	 *            date.
	 */
	@Override
	public void setRegistrationDateAndTime(int year, int month, int day,
			int hour, int minute) {
		this.regTime = LocalDateTime.of(year, month, day, hour, minute);
	}

	/**
	 * @param datetime
	 *           Optional clause to set the regtime as a LocalDateTime object
	 */
	@Override
	public void setRegistrationDateAndTime(Optional<LocalDateTime> datetime){
		this.regTime = datetime.orElse(null);

	}

	/**
	 * @param year,
	 *            month, day, hour, minute, sec Set the triage time and date
	 */
	@Override
	public void setTriageDateAndTime(int year, int month, int day, int hour,
			int minute) {
		LocalDateTime t =  LocalDateTime.of(year, month, day, hour, minute);
		if (regTime.compareTo(t)<0)
			this.triageTime = t;
		else
			throw new IllegalArgumentException("Registration date must be before"
					+ "the triage time");
			
	}

	/**
	 * @param datetime
	 *            Optional clause to set the triage time as a LocalDateTime
	 *            object
	 */
	@Override
	public void setTriageDateAndTime(Optional<LocalDateTime> datetime) {
		if (regTime.compareTo(datetime.orElse(null))<0)
		this.triageTime = datetime.orElse(null);
		else
			throw new IllegalArgumentException("Registration date must be before"
					+ "the triage time");
			
	}
/**
 * Overridden to String method in order to create an asterix separated
 * string of information about a clinic visit includes: RAMQ, registration
 * time, and optionally the triage time, priority and complaint.
 * 
 * @return The above mentioned string.
 */
@Override
public String toString() {
	String prio = "";
	if (priority != Priority.NOTASSIGNED)
		prio = "" + priority.getCode();
	if (triageTime == null)
		return (this.patient.getRamq() + "*" + regTime.getYear()
		+ "*" + regTime.getMonthValue() + "*"+ regTime.getDayOfMonth() + 
		"*" + regTime.getHour() + "*" + regTime.getMinute() + "*" + "" + 
		"*" + "" + "*" + "" + "*" + "" + "*" + "" + "*" + prio +
		"*" + this.getComplaint());
	else
			return (this.patient.getRamq() + "*" + regTime.getYear() +
			"*" + regTime.getMonthValue() + "*"
			+ regTime.getDayOfMonth() + "*" + regTime.getHour() + 
			"*" + regTime.getMinute() + "*"
			+ triageTime.getYear() + "*" + triageTime.getMonthValue() + 
			"*" + triageTime.getDayOfMonth() + "*"
			+ triageTime.getHour() + "*" + triageTime.getMinute() + "*" + 
			prio + "*" + this.getComplaint());
}

}
