package group3.clinic.business;

import java.time.DateTimeException;
import java.time.LocalDate;

import dw317.lib.Gender;
import dw317.lib.Name;

import java.io.Serializable;

/**
 * 
 * @author Evan Version 2015-09-28 Ramq Class
 *
 */
public class Ramq implements Comparable<Ramq>, Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2132354815498782012L;
	private String ramq;

	/**
	 * @param ramq
	 *            Default Constructor for Ramq Class.
	 */
	public Ramq(String ramq) {
		if (validateRamqNumeric(ramq))
			this.ramq = ramq;
		else
			throw new IllegalArgumentException();

	}

	/**
	 * Overloaded Ramq constructor.
	 * 
	 * @param ramq
	 * @param name
	 */
	public Ramq(String ramq, Name name) {
		if (validateRamq(ramq, name))
			this.ramq = ramq;
		else
			throw new IllegalArgumentException();
	}

	/**
	 * Uses class ramq string to create a LocalDate object which stores a
	 * birthdate
	 * 
	 * @return LocalDate
	 */
	public LocalDate getBirthdate() {
		String ramqId = this.ramq;
		String birthdate = "";

		for (int i = 4; i < 10; i++) {
			birthdate += ramqId.charAt(i);
		}

		int year = Integer.parseInt(birthdate.substring(0, 2));
		if (year <= 15)
			year += 2000;
		else
			year += 1900;

		int month = Integer.parseInt(birthdate.substring(2, 4));
		if (month > 50)
			month = month - 50;

		int day = Integer.parseInt(birthdate.substring(4));

		LocalDate bday = LocalDate.of(year, month, day);
		return bday;

	}

	/**
	 * Identifies the gender from the Ramq and returns the appropriate Enum
	 * gender.
	 * 
	 * @return Gender
	 */
	public Gender getGender() {
		String ramqId = this.ramq;
		String birthdate = "";

		for (int i = 4; i < 10; i++) {
			birthdate += ramqId.charAt(i);
		}

		int month = Integer.parseInt(birthdate.substring(2, 4));
		if (month > 50)
			return Gender.FEMALE;
		else
			return Gender.MALE;
	}

	/**
	 * returns the Class' ramq string.
	 * 
	 * @return ramq
	 */
	public String getRamq() {
		return ramq;
	}

	/**
	 * Validates the Numeric values of the ramq string does not validate
	 * integrity of the patients birthday. Only checks if range of the numbers
	 * are valid.
	 * 
	 * @param ramq
	 * @return boolean
	 */
	private boolean validateRamqNumeric(String ramq) {
		boolean isValid = true;

		if(ramq == null)
			isValid = false;
		if(ramq.equals(""))
			isValid = false;
		if(ramq.length() != 12)
			isValid = false;
		
		int year;
		if (isNumeric(ramq.substring(4, 6)))
			year = Integer.parseInt(ramq.substring(4, 6));
		else
			throw new NumberFormatException();

		if (year < 0 || year > 99) {
			isValid = false;
			throw new IllegalArgumentException("Illegal Argument Exception, Argument out of range");
		}
			
		

		int month;
		if (isNumeric(ramq.substring(6, 8)))
			month = Integer.parseInt(ramq.substring(6, 8));
		else
			throw new NumberFormatException();

		if (month > 50)
			month = month - 50; 
		
		if (month < 1 || month > 12) {
			isValid = false;
			throw new IllegalArgumentException("Illegal Argument Exception, argument out of range!");
		}

		int day;
		if (isNumeric(ramq.substring(8, 10)))
			day = Integer.parseInt(ramq.substring(8, 10));
		else
			throw new NumberFormatException();
		
		if (day <1 || day > 31) {
			isValid = false;
			throw new IllegalArgumentException("Illegal Argument Exception, argument out of range!");
		}
		try{
			LocalDate date = LocalDate.of(year, month, day);
		}catch(DateTimeException dte){
			// UNCOMMENT AFTER DEBUGG
			//throw new IllegalArgumentException("Illegal Argument Exception, date is impossible!");
		}

		return isValid;

	}

	/**
	 * Data validation of the ramq object. Ensures last name and first name are
	 * appropriately used following the ramq guide lines first three characters
	 * being to first three characters of last name (upper case) and the fourth
	 * character is the first character of the first name (upper case)
	 * 
	 * calls validateRamqNumeric to validate the numeric values.
	 * 
	 * @param ramq
	 * @param name
	 * @return boolean
	 */
	private boolean validateRamq(String ramq, Name name) {
		// validate alpha characters corresponding to name.
		boolean isValid = false;

		String lastName = name.getLastName();
		if (isChar(lastName))
			lastName = lastName.trim().toUpperCase();
		else
			throw new IllegalArgumentException();

		String firstName = name.getFirstName();
		if (isChar(firstName))
			firstName = firstName.trim().toUpperCase();
		else
			throw new IllegalArgumentException();

		if (ramq.substring(0, 3).equals(lastName.substring(0, 3)))
			if (ramq.substring(3, 4).equals(firstName.substring(0, 1)))
				isValid = true;
			else {
				isValid = false;
				throw new IllegalArgumentException("Incorrect Name, check if characters are upperCase.");
			}
		else {
			isValid = false;
			throw new IllegalArgumentException("Incorrect Name, check if characters are upperCase.");
		}

		if (validateRamqNumeric(ramq) && isValid)
			return isValid = true;
		else
			return isValid = false;
	}

	/**
	 * Compares two objects to ensure they are equal. In this case, two objects
	 * are equal if the ramq strings that they return are equal.
	 * 
	 * @param Object
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (obj.getClass() != this.getClass())
			return false;

		Ramq ramq = (Ramq) obj;
		if (ramq.getRamq().equals(this.getRamq()))
			return true;

		if (this.compareTo(ramq) == 0)
			return true;

		return false;

	}

	/**
	 * Overridden toString method, returns the ramq string.
	 * 
	 * @return String
	 */
	@Override
	public String toString() {
		return ramq;
	}

	/**
	 * Overridden compareTo method, Compares the two ramq strings.
	 * 
	 * @param Ramq
	 * @return integer
	 */
	@Override
	public int compareTo(Ramq o) {
		if (this.ramq.equals(null))
			throw new NullPointerException();

		if (this.ramq.compareTo(o.ramq) > 0)
			return 10;

		if (this.ramq.compareTo(o.ramq) == 0)
			return 0;
		else
			return -10;
	}

	/**
	 * Overridden hashCode method, creates unique hashCodes for Ramq objects.
	 * 
	 * @return integer
	 */
	@Override
	public int hashCode() {
		int prime = 137;
		int result = (int) prime / 11;
		result += ramq.hashCode();
		return result;
	}

	private boolean isNumeric(String str) {
		try {
			@SuppressWarnings("unused")
			int i = Integer.parseInt(str);
		} catch (NumberFormatException NFE) {
			return false;
		}
		return true;
	}

	private boolean isChar(String s) {
		char[] chars = s.toCharArray();
		for (char c : chars) {
			if (!Character.isLetter(c) && !(c == '\'') && !(c == '-'))
				return false;
		}
		return true;

	}
}
