package group3.clinic.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;
import java.util.Optional;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import dw317.clinic.ClinicFactory;
import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.Visit;
import dw317.clinic.data.NonExistingVisitException;
import dw317.clinic.data.interfaces.PatientDAO;
import dw317.clinic.data.interfaces.VisitDAO;
import group3.clinic.business.Clinic;
import group3.clinic.business.Priority;
import group3.clinic.data.ObjectSerializedList;
import group3.clinic.data.PatientListDB;
import group3.clinic.data.VisitQueueDB;
import group3.dawsonclinic.DawsonClinicFactory;

public class GUIViewController extends JFrame implements Observer {

	private JPanel app_pane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private Clinic model;
	JTextArea output = new JTextArea();
	int choice = 0;
	String result;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		ClinicFactory factory = DawsonClinicFactory.DAWSON_CLINIC;
		PatientDAO patientDb = new PatientListDB(
				new ObjectSerializedList("datafiles/database/patients.ser", "datafiles/database/visits.ser"),
				factory.getPatientVisitFactory());
		VisitDAO visitDb = new VisitQueueDB(
				new ObjectSerializedList("datafiles/database/patients.ser", "datafiles/database/visits.ser"),
				factory.getPatientVisitFactory());

		Clinic model = new Clinic(patientDb, visitDb, factory);

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUIViewController frame = new GUIViewController(model);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUIViewController(Clinic model) {
		// Modified constructor
		this.model = model;
		model.addObserver(this);
		update(model, this.model);

		// Application pane
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 420, 520);
		app_pane = new JPanel();
		app_pane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(app_pane);
		app_pane.setLayout(new BorderLayout(0, 0));

		// Header panel
		JPanel header = new JPanel();
		app_pane.add(header, BorderLayout.NORTH);

		// Label inside the header panel
		JLabel lblNewLabel = new JLabel("Dawson Medical Clinic");
		lblNewLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
		header.add(lblNewLabel);

		// Side panel holding the actions
		JPanel side_panel = new JPanel();
		app_pane.add(side_panel, BorderLayout.WEST);

		// Main panel holding the priorities and select button
		JPanel main_panel = new JPanel();
		app_pane.add(main_panel, BorderLayout.CENTER);

		// Radio button for reanimation
		JRadioButton rad_reanimation = new JRadioButton("Reanimation");
		rad_reanimation.setVisible(false); // Initiation invisible
		buttonGroup.add(rad_reanimation);

		// Radio button for urgent
		JRadioButton rad_urgent = new JRadioButton("Urgent");
		rad_urgent.setVisible(false); // Initiation invisible
		buttonGroup.add(rad_urgent);

		// Radio button for very urgent
		JRadioButton rad_veryurgent = new JRadioButton("Very Urgent");
		rad_veryurgent.setVisible(false); // Initiation invisible
		buttonGroup.add(rad_veryurgent);

		// Radio button for not urgent
		JRadioButton rad_noturgent = new JRadioButton("Not Urgent");
		rad_noturgent.setVisible(false); // Initiation invisible
		buttonGroup.add(rad_noturgent);

		// Radio button for less urgent
		JRadioButton rad_lessurgent = new JRadioButton("Less Urgent");
		rad_lessurgent.setVisible(false); // Initiation invisible
		buttonGroup.add(rad_lessurgent);

		// Button to select priority and event
		JButton btn_selpriority = new JButton("Select");
		btn_selpriority.setVisible(false); // Initiation invisible
		// Output window

		// Next To Triage button and event
		JButton btn_nexttri = new JButton("Next To Triage");
		btn_nexttri.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rad_reanimation.setVisible(false);
				rad_veryurgent.setVisible(false);
				rad_urgent.setVisible(false);
				rad_lessurgent.setVisible(false);
				rad_noturgent.setVisible(false);
				btn_selpriority.setVisible(false);

				output.setText("");

				try {

					output.setText("Next Visit: "
							+ model.nextForTriage().orElse(null).getPatient().getName().getFullName().toString());

				} catch (NullPointerException npe) {
					output.setText("End of database");
				}
			}
		});

		// Next To Examine button and event
		JButton btn_nextexa = new JButton("Next to examine");
		btn_nextexa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rad_reanimation.setVisible(false);
				rad_veryurgent.setVisible(false);
				rad_urgent.setVisible(false);
				rad_lessurgent.setVisible(false);
				rad_noturgent.setVisible(false);
				btn_selpriority.setVisible(false);
				try {
					output.setText("");
					output.setText("Next Visit: "
							+ model.nextForExamination().orElse(null).getPatient().getName().getFullName().toString());
				} catch (NullPointerException npe) {
					output.setText("End of database");
				}
			}
		});

		btn_selpriority.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					output.setText("");
					if (rad_reanimation.isSelected()) {
						model.changeTriageVisitPriority(Priority.values()[1]);
						output.setText("Triaged visit priority changed to: " + Priority.values()[1]);
					}
					if (rad_veryurgent.isSelected()) {
						model.changeTriageVisitPriority(Priority.values()[2]);
						output.setText("Triaged visit priority changed to: " + Priority.values()[2]);
					}
					if (rad_urgent.isSelected()) {
						model.changeTriageVisitPriority(Priority.values()[3]);
						output.setText("Triaged visit priority changed to: " + Priority.values()[3]);
					}
					if (rad_lessurgent.isSelected()) {
						model.changeTriageVisitPriority(Priority.values()[4]);
						output.setText("Triaged visit priority changed to: " + Priority.values()[4]);
					}
					if (rad_noturgent.isSelected()) {
						model.changeTriageVisitPriority(Priority.values()[5]);
						output.setText("Triaged visit priority changed to: " + Priority.values()[5]);

					}
				} catch (NonExistingVisitException neve) {
					output.setText("Patient does not exist");
				}

				// Set visibility of all buttons to false except for output
				// panel
				rad_reanimation.setVisible(false);
				rad_veryurgent.setVisible(false);
				rad_urgent.setVisible(false);
				rad_lessurgent.setVisible(false);
				rad_noturgent.setVisible(false);
				btn_selpriority.setVisible(false);
			}
		});

		// Prioritize Triage button and event
		JButton btn_prioritize = new JButton("Prioritize Triage");
		btn_prioritize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Set visibility of all buttons to true except for output panel
				rad_reanimation.setVisible(true);
				rad_veryurgent.setVisible(true);
				rad_urgent.setVisible(true);
				rad_lessurgent.setVisible(true);
				rad_noturgent.setVisible(true);
				btn_selpriority.setVisible(true);
			}
		});

		// Grouping the buttons and giving them a vertical and horizontal
		// constraints
		GroupLayout gl_side_panel = new GroupLayout(side_panel);
		gl_side_panel.setHorizontalGroup(gl_side_panel.createParallelGroup(Alignment.LEADING)
				.addComponent(btn_nexttri, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
				.addComponent(btn_prioritize, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
				.addComponent(btn_nextexa, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE));
		gl_side_panel
				.setVerticalGroup(
						gl_side_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_side_panel.createSequentialGroup().addGap(5)
										.addComponent(btn_nexttri, GroupLayout.PREFERRED_SIZE, 60,
												GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(btn_prioritize, GroupLayout.PREFERRED_SIZE, 60,
										GroupLayout.PREFERRED_SIZE).addGap(6)
				.addComponent(btn_nextexa, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)));
		side_panel.setLayout(gl_side_panel);

		// Button to exit and event
		JButton btn_exit = new JButton("Exit");
		btn_exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Close application without error
				System.exit(0);
			}
		});

		// Grouping
		GroupLayout gl_main_panel = new GroupLayout(main_panel);
		gl_main_panel
				.setHorizontalGroup(
						gl_main_panel.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_main_panel.createSequentialGroup().addContainerGap()
										.addGroup(gl_main_panel.createParallelGroup(Alignment.LEADING)
												.addGroup(gl_main_panel.createSequentialGroup()
														.addComponent(rad_reanimation).addContainerGap())
												.addComponent(btn_selpriority, GroupLayout.DEFAULT_SIZE, 264,
														Short.MAX_VALUE)
						.addGroup(gl_main_panel.createSequentialGroup()
								.addGroup(gl_main_panel.createParallelGroup(Alignment.LEADING)
										.addComponent(rad_veryurgent).addComponent(rad_urgent)
										.addComponent(rad_lessurgent).addComponent(rad_noturgent))
								.addContainerGap(181, Short.MAX_VALUE))
						.addComponent(output, GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE))));
		gl_main_panel
				.setVerticalGroup(gl_main_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_main_panel.createSequentialGroup().addContainerGap().addComponent(rad_reanimation)
								.addPreferredGap(ComponentPlacement.RELATED).addComponent(rad_veryurgent)
								.addPreferredGap(ComponentPlacement.RELATED).addComponent(rad_urgent)
								.addPreferredGap(ComponentPlacement.RELATED).addComponent(rad_lessurgent)
								.addPreferredGap(ComponentPlacement.RELATED).addComponent(rad_noturgent)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(btn_selpriority, GroupLayout.PREFERRED_SIZE, 23,
										GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(output, GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
								.addContainerGap()));

		JPanel footer = new JPanel();
		app_pane.add(footer, BorderLayout.SOUTH);

		main_panel.setLayout(gl_main_panel);
		footer.add(btn_exit);
		this.setVisible(true);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void update(Observable o, Object arg) {
		result = "";
		if (arg instanceof Optional<?>)
			result = "Next Visit:\n\n" + ((Optional<Visit>) arg).get().getPatient().getName();
		else if (arg instanceof Patient)
			result = ((Patient) arg).getName().toString() + "\n" + ((Patient) arg).getRamq().toString();
		else if (arg instanceof Priority)
			result = "Priority changed to " + ((Priority) arg);
		output.setText(result);

	}
}
