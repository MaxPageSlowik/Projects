/**
 * 
 */
package group3.clinic.ui;
import java.util.Observable;
import java.util.Observer;
import java.util.Optional;

import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.Visit;
import group3.clinic.business.Priority;
/**
 * @author group3
 *
 */
public class TextView implements Observer{
	
	public TextView (Observable model){
		model.addObserver(this);
	}

	@Override
	public void update(Observable o, Object arg) {
		if (arg instanceof Optional<?>){
			displayOptionalVisit((Visit)((Optional) arg).orElse(null));
		}
		if (arg instanceof Priority){
			displayPriority((Priority)arg);
		}
		if (arg instanceof Patient){
			displayPatient((Patient)arg);
		}
		if (arg instanceof Visit){
			displayVisit((Visit)arg);
		}
	}
	private void displayOptionalVisit(Visit object){
		System.out.print("Next visit: "+object.getPatient().getName().getLastName()
				+ ", "+ object.getPatient().getName().getFirstName());
		System.out.println("");
	}
	private void displayVisit(Visit object){
		if(object == null)
			System.out.println("No visit by that description");
		else
		{
			displayPatient(object.getPatient());
			System.out.println("New visit for: ");
			System.out.println(object.getPatient().getName().getLastName()
					+ ", "+ object.getPatient().getName().getFirstName());
		}
	}
	private void displayPriority(Priority p){
		System.out.println(p.toString());
	}
	private void displayPatient(Patient object){
		System.out.println("Patient Information");
		System.out.println("RAMQ: "+ object.getRamq());
		System.out.println(object.getName().getLastName()+", "+
		object.getName().getFirstName());
		System.out.println(object.getTelephoneNumber());
	}
}
