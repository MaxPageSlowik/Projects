/**
 * 
 */
package group3.clinic.ui;

import java.io.IOException;
import java.util.Scanner;

import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.PatientVisitManager;
import dw317.clinic.business.interfaces.Visit;
import dw317.clinic.data.DuplicatePatientException;
import dw317.clinic.data.NonExistingPatientException;
import dw317.clinic.data.NonExistingVisitException;
import dw317.lib.medication.Medication;
import group3.clinic.business.Priority;

/**
 * @author group3
 *
 */
public class TextController {
	private PatientVisitManager model;

	private enum Command {
		PATIENT_INFO, NEW_PATIENT, NEW_VISIT, NEXT_TO_TRIAGE, CHANGE_PRIORITY, NEXT_TO_EXAMINE, STOP
	}

	public TextController(PatientVisitManager model) {
		this.model = model;
	}

	public void run() {
		int choice = -1; // Initiating input to something other than 7
		while(choice != 7){
			displayMenu();
			// Asking for input until it is correct
			choice = getInput();
			
			while(choice < 1 || choice > 7){
				System.out.println("\n" + "Bad choice, please re-enter a valid choice: ");
				choice = getInput();
			}
			
			if (choice == 1) {
				try {
					System.out.print("Enter the ramq: ");
					Patient p = model.findPatient(getStringInput());

				} catch (NonExistingPatientException e) {
					System.out.println("Patient cannot be found");
				} catch (IllegalArgumentException e){
					System.out.println("Bad RAMQ");
				}
			}
			if (choice == 2) {
				getPatientInput();
			}
			if (choice == 3) {
				getVisitInput();
			}
			if (choice == 4) {
				nextForTirage();
			}
			if (choice == 5) {
				change_prio();
			}
			if (choice == 6) {
				next_examination();
			}
			if (choice == 7) {
				try {
					model.closeClinic();
					System.exit(0);
				} catch (IOException e) {
					System.out.println(e.getMessage());
					System.exit(1);
				}
			}
		}
	}

	private void displayMenu() {
		System.out.println("Dawson Clinic Menu");
		System.out.println("Select a choice from the menu");
		for (int i = 0; i < Command.values().length; i++) {
			System.out.println("\t " + (i + 1) + " - " + Command.values()[i]);
			
		}
		System.out.println();
		System.out.print("Enter your choice: ");
	}

	private int getInput() {
		int choice = 0;
		Scanner key = new Scanner(System.in);
		choice = key.nextInt();
		return choice;
	}

	private String getStringInput() {
		String input;
		Scanner key = new Scanner(System.in);
		input = key.nextLine();
		// key.close();
		return input;
	}

	private void getVisitInput() {
		System.out.print("Please enter the ramq: ");
		Patient p;
		try {
			p = model.findPatient(getStringInput());
			System.out.print("Please enter the primary complaint of patients, or press enter if unknown");
			model.createVisit(p, getStringInput());
		} catch (NonExistingPatientException e) {
			System.out.println(e.getMessage());
		} catch ( IllegalArgumentException e){
			System.out.println("Bad RAMQ");

		}

	}

	private void getPatientInput() {

		System.out.print("Please enter the first name: ");
		String fn = getStringInput();
		System.out.print("Please enter the last name: ");
		String ln = getStringInput();
		System.out.print("Please enter the ramq: ");
		String ramq = getStringInput();
		System.out.print("Please enter the phone number: ");
		String t = getStringInput();
		System.out.print("Please enter any existing medical conditions, or press enter if none available: ");
		String conditions = getStringInput();
		Medication meds;
		meds = Medication.getInstance(Medication.Scheme.DIN, "02181061", "Tylenol");

		try {
			model.registerNewPatient(fn, ln, ramq, t, meds, conditions);

		} catch (DuplicatePatientException e) {
			System.out.println(e.getMessage());

		} catch (NullPointerException e) {
			System.out.println("not conditions");
		}catch (IllegalArgumentException e){
			System.out.println("Invalid entry");
		}

	}

	private void nextForTirage() {
		
		model.nextForTriage();
	}

	private void change_prio() {
		for (int i = 1; i < Priority.values().length; i++) {
			System.out.println("\t" + (i + 1) + " - " + Priority.values()[i]);
		}
		
		System.out.println("\n" + "Enter Your choice: ");
		int choice = getInput();
		
		// Asking for input until it is correct
		while(choice < 2 || choice > 6){
			System.out.println("\n" + "Bad choice, please re-enter a valid choice: ");
			choice = getInput();
		}
		
		Priority selectedPrio = Priority.values()[choice - 1];
		try {
			model.changeTriageVisitPriority(selectedPrio);
		} catch (NonExistingVisitException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("Triaged visit priority changed to: " + selectedPrio.toString());
	}

	private void next_examination() {
		try{
		model.nextForExamination();
		} catch (NullPointerException npe) {
			System.out.println("End of database");
		}
	}
}