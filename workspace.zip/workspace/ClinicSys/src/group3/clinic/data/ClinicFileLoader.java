package group3.clinic.data;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;

import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.Visit;
import dw317.lib.medication.Medication;
import group3.clinic.business.ClinicPatient;
import group3.clinic.business.ClinicVisit;
import group3.clinic.business.Priority;
import group3.clinic.business.Ramq;

public class ClinicFileLoader {

	private ClinicFileLoader() {
	}

	/**
	 * @author Evan Glickakis, Jonathan Bizier
	 *
	 */
	/**
	 * 
	 * @param filename
	 * @return A fully loaded Array with the patients from a file
	 * @throws IOException
	 */
	public static Patient[] getPatientListFromSequentialFile(String filename) throws IOException {
		// Initialize needed variables
		Patient[] patient_list = new Patient[2];
		BufferedReader inputFile = null;
		String recordStr = null;

		try {
			inputFile = new BufferedReader(
					new InputStreamReader(new FileInputStream(filename), StandardCharsets.UTF_8));

			String[] fields = null;
			int i = 0;
			
			
			// Read the first line
			recordStr = inputFile.readLine();

			// If not at the end of file
			while (recordStr != null) {
				// Create split array from string
				fields = recordStr.trim().split("\\*");

				// if first field is empty, it means that the string is not
				// formatted correctly
				if (fields.length>1){
				if (fields[0].isEmpty()) {
					// If string isn't formated, skip line and do the next
					inputFile.readLine();
					i++;
					
				}
				
				else {

					try {
						
						patient_list[i] = new ClinicPatient(fields[1], fields[2], fields[0]);
						try {
							// Try to fill the visit if the fields are not null
							// because split returns null if *****
							patient_list[i].setTelephoneNumber(Optional.of(fields[3]));
							patient_list[i].setMedication(Optional.of(Medication.getInstance
									(Medication.Scheme.valueOf(fields[4]), fields[5], fields[6])));
							patient_list[i].setExistingConditions(Optional.of(fields[7]));
							
								
							
						} catch (Exception e) {
							
							inputFile.readLine();
							// Do nothing since we are just trying to fill the
							// visits
						}

						i++;
						// check if capacity surpassed and resize
						if (i >= patient_list.length) {
							patient_list = Arrays.copyOf(patient_list, patient_list.length * 2);
						}

					} catch (ArrayIndexOutOfBoundsException e) {
						// Do nothing since we are just trying to fill the
						// visits
					} finally {
						// secondary read to continue in loop
						recordStr = inputFile.readLine();
					}
				}
				}
			} // end while
				// shrink array if necessary
			if (i < patient_list.length)
				patient_list = java.util.Arrays.copyOf(patient_list, i);
			return patient_list;
		} // end try
		catch (IOException e) {
			System.out.println("Could not open file: " + filename + "!");
			return new Patient[0];
		} finally {
			// BufferedReader�s close method may throw an IOException!
			try {
				if (inputFile != null)
					inputFile.close();
			} catch (IOException e) {
				System.out.println("Closing error " + filename);
			}
		}
	}

	/**
	 * @author Jonathan Bizier, Evan Glickakis
	 *
	 */
	/**
	 * 
	 * @param filename
	 * @return A fully loaded Array with the visits from a file
	 * @throws IOException,
	 *             IllegalArgumentException, NullPointerException
	 */
	public static Visit[] getVisitListFromSequentialFile(String filename, Patient[] patient_list)
			throws IOException, IllegalArgumentException, NullPointerException {

		// Initialize needed variables
		Visit[] visit_list = new Visit[2];
		BufferedReader inputFile = null;
		String recordStr = null;

		try {
			// Setup reader to read from file
			inputFile = new BufferedReader(
					new InputStreamReader(new FileInputStream(filename), StandardCharsets.UTF_8));

			// Initiate array that will hold fields from the line that was split
			String[] fields = null;
			int i = 0;

			// Read the first line
			recordStr = inputFile.readLine();

			// If not at the end of file
			while (recordStr != null) {
				// Create split array from string
				fields = recordStr.trim().split("\\*");

				// if first field is empty, it means that the string is not
				// formatted correctly
				if (fields[0] == null) {
					// If string isn't formated, skip line and do the next
					inputFile.readLine();
					i++;
				} else {
					try {
						// Temporary Ramq to match it to the patient_list
						// patient ramq
						Ramq ramq_temp = new Ramq(fields[0]);

						// Loop going through every patient in the list
						for (Patient patient : patient_list) {
							if (ramq_temp.equals(patient.getRamq())) {
								// When patient is found, assign it to a field
								// in the visit array
								visit_list[i] = new ClinicVisit(patient);
								try {
									// Try to fill the visit if the fields are
									// not null because split returns null if
									// *****
									visit_list[i].setPriority(Priority.values()[Integer.parseInt(fields[11])]);
									visit_list[i].setRegistrationDateAndTime(Integer.parseInt(fields[1]),
											Integer.parseInt(fields[2]), Integer.parseInt(fields[3]),
											Integer.parseInt(fields[4]), Integer.parseInt(fields[5]));
									LocalDateTime ld = LocalDateTime.of(Integer.parseInt(fields[6]),
											Integer.parseInt(fields[7]), Integer.parseInt(fields[8]),
											Integer.parseInt(fields[9]), Integer.parseInt(fields[10]));
									visit_list[i].setTriageDateAndTime(Optional.of(ld));
									visit_list[i].setComplaint(Optional.of(fields[12]));
								} catch (Exception e) {
									// Do nothing since we are just trying to
									// fill the visits
								}
							}
						}

						// Check if user was found
						if (visit_list[i] == null) {
							throw new IllegalArgumentException("Patient could not be found: " + ramq_temp.getRamq());
						}

						// After everything is done, do it for the next visit in
						// the list
						i++;

						// check if capacity surpassed and resize
						if (i >= visit_list.length) {
							visit_list = Arrays.copyOf(visit_list, visit_list.length * 2);
						}

					} catch (Exception e) {
						// ignore records with less that 2 fields
					} finally {
						// secondary read to continue in loop
						recordStr = inputFile.readLine();

					}
				}
			}

			// Shrink array if needed
			if (i < visit_list.length) {
				visit_list = java.util.Arrays.copyOf(visit_list, i);
			}

			// Return fully loaded list
			return visit_list;

		} catch (IOException e) {
			// Print message and return empty array if file cannot be opened
			System.out.println("Could not open file: " + filename + "!");
			return new Visit[0];
		}

		finally {
			// In case something happens with the BufferedReader
			try {
				if (inputFile != null) {
					// Close the file when finished
					inputFile.close();
				}
			} catch (IOException e) {
				System.out.println("Could not close file: " + filename + "!");
			}
		}
	}
}