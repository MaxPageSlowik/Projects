/**
 * 
 */
package group3.clinic.data;

import java.io.IOException;

/**
 * @author 1437203
 *
 */
public class SerializingDB {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ObjectSerializedList osl = new ObjectSerializedList("./datafiles/database/patients.ser",  "./datafiles/database/visits.ser");
		try {
			osl.convertSequentialFilesToSerialized("./datafiles/database/patients.txt",  "./datafiles/database/visits.txt");
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
