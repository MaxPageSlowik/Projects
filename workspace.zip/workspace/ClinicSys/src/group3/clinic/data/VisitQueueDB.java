/**
 * 
 */
package group3.clinic.data;

import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.Queue;

import dw317.clinic.DefaultPatientVisitFactory;
import dw317.clinic.business.interfaces.PatientVisitFactory;
import dw317.clinic.business.interfaces.Visit;
import dw317.clinic.data.NonExistingVisitException;
import dw317.clinic.data.interfaces.VisitDAO;
import group3.clinic.business.Priority;

/**
 * @author group3
 *
 */
public class VisitQueueDB implements VisitDAO {

	private List<Queue<Visit>> database;
	private final ListPersistenceObject listPersistenceObject;
	private final PatientVisitFactory factory;

	public VisitQueueDB(ListPersistenceObject listPersistenceObject) {
		this.listPersistenceObject = listPersistenceObject;
		this.factory = DefaultPatientVisitFactory.DEFAULT;
			
		if (database != null) {
				database = listPersistenceObject.getVisitDatabase();
		}
	}

	public VisitQueueDB(ListPersistenceObject listPersistenceObject, PatientVisitFactory factory) {
		this.listPersistenceObject = listPersistenceObject;
		this.factory = factory;
		database = listPersistenceObject.getVisitDatabase();
	}

	@Override
	public void add(Visit aVisit) {
		if(aVisit == null)
			throw new IllegalArgumentException("Must provide a visitor in order to add to"
					+ "the database");
		aVisit = factory.getVisitInstance(factory.getPatientInstance
				(aVisit.getPatient().getName().getFirstName(),
				 aVisit.getPatient().getName().getLastName(), 
				 aVisit.getPatient().getRamq().toString()));
		Priority priority = aVisit.getPriority();
		int index = priority.getCode();
		database.get(index).offer(aVisit);

	}

	@Override
	public void disconnect() throws IOException {
		if (database == null)
			throw new IOException("Cannot disconnect from database, "
					+ "connection was never established");
		else{
		listPersistenceObject.saveVisitDatabase(database);
		database = null;
		}
	}

	@Override
	public Optional<Visit> getNextVisit(Priority priority) {
		if (priority ==null & priority.getCode()<0 & priority.getCode()>5)
			throw new IllegalArgumentException("Must be a priority between 0-5");
		return Optional.ofNullable(database.get(priority.getCode()).peek());

	}

	@Override
	public void remove(Priority priority) {
		if (priority == null & priority.getCode()<0 & priority.getCode()>5)
			throw new IllegalArgumentException("Must be a priority between 0-5");
		int index = priority.getCode();
		database.get(index).poll();

	}

	@Override
	public int size(Priority priority) {
		if (priority ==null & priority.getCode()<0 & priority.getCode()>5)
			throw new IllegalArgumentException("Must be a priority between 0-5");
		int index = priority.getCode();
		return database.get(index).size();
	}

	@Override
	public void update(Priority oldPriority, Priority newPriority) throws NonExistingVisitException {
		if (database.get(oldPriority.getCode()).peek()==(null))
			throw new NonExistingVisitException("No one has that priority code");
		else{
		
		int indexOld = oldPriority.getCode();
		int indexNew = newPriority.getCode();
		database.get(indexOld).peek().setPriority(newPriority);
		database.get(indexNew).offer(database.get(indexOld).peek());
		database.get(indexOld).poll();
		}

	}

	@Override
	public String toString() {
		if(database == null)
			return null;
		StringBuilder stringDB = new StringBuilder();
		for (int i = 0; i <= 5; i++) {
			stringDB.append("Number of priority " + i + " visits in Database: " + database.get(i).size() + "\n");
			for (Visit v : database.get(i))
				stringDB.append(v + "\n");
		}

		return stringDB.toString();

	}

}
