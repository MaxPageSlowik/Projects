/**
 * 
 */
package group3.clinic.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import dw317.clinic.DefaultPatientVisitFactory;
import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.PatientVisitFactory;
import dw317.clinic.data.DuplicatePatientException;
import dw317.clinic.data.NonExistingPatientException;
import dw317.clinic.data.interfaces.PatientDAO;
import dw317.lib.medication.Medication;
import group3.clinic.business.ClinicPatient;
import group3.clinic.business.Ramq;
import group3.util.ListUtilities;

/**
 * @author group3
 *
 */
public class PatientListDB implements PatientDAO {
	
	private List<Patient> database;
	private final ListPersistenceObject listPersistenceObject;
	private final PatientVisitFactory factory; 
		
	public PatientListDB (ListPersistenceObject listPersistenceObject){
		this.listPersistenceObject = listPersistenceObject;
		this.factory = DefaultPatientVisitFactory.DEFAULT;
		database = listPersistenceObject.getPatientDatabase();
	}
	
	public PatientListDB (ListPersistenceObject listPersistenceObject,
						PatientVisitFactory factory){
		this.listPersistenceObject = listPersistenceObject;
		this.factory = factory;
		database = listPersistenceObject.getPatientDatabase();
	}

	@Override
	public void add(Patient aPatient) throws DuplicatePatientException {
		if (aPatient != null && !exists(aPatient.getRamq())){
			aPatient = factory.getPatientInstance
					(aPatient.getName().getFirstName(), aPatient.getName().getLastName(),
					 aPatient.getRamq().toString());
		}
		else{
			throw new DuplicatePatientException("The patient:" + aPatient.getRamq() +" already exists");
		}
		int index = binarySearch(aPatient.getRamq());
		database.add(-index - 1,aPatient);
		
	}

	@Override
	public void disconnect() throws IOException {
		if (database == null){
			throw new IOException("Cannot disconnect from database since no connection was initialy established");
		}
		else{
			listPersistenceObject.savePatientDatabase(database);
			database = null;
		}
		
		
	}

	@Override
	public Patient getPatient(Ramq ramq) throws NonExistingPatientException {
		if(ramq != null && exists(ramq))
			return database.get(binarySearch(ramq));
		else
			throw new NonExistingPatientException("Patient " + ramq + " does not exist!");
			
	}

	@Override
	public boolean exists(Ramq ramq) {
		if (ramq != null && binarySearch(ramq) < 0)
			return false;
		else
			return true;
	}

	@Override
	public List<Patient> getPatientsPrescribed(Medication medication) {
		if (medication == null){
			return null;
		}
		
		List<Patient> patients = new ArrayList<Patient>();
		for (Patient patient : database)
			if (patient.getMedication().orElse(null) != null)
				if (patient.getMedication().orElse(null).equals(medication))
					patients.add(patient);

		
		return patients;
	}

	@Override
	public void update(Patient modifiedPatient) throws NonExistingPatientException {
		if (modifiedPatient != null && exists(modifiedPatient.getRamq())){
			int index = binarySearch(modifiedPatient.getRamq());
			database.set(index, modifiedPatient);
		}
		else{
			throw new NonExistingPatientException("Patient " + modifiedPatient.getRamq() + " does not exist!");
		}
			
	}
	
	private int binarySearch(Ramq ramq) {
		if (ramq == null){
			return -1;
		}
		
		int max = database.size()-1;
		int min = 0;
		int mid = 0;
		int result = 0;
		
		while (min <= max){
			mid = (max+min)/2;
			result = database.get(mid).getRamq().compareTo(ramq);
			if (result>0)
				max =mid-1;
			else if (result <0)
				min = mid+1;
			else
				return mid;
		}
		return -(min + 1);
		
	}
	@Override
	public String toString(){
		if (database == null){
			return "Number of patients in database: " + null;
		}
		
		StringBuilder stringDB = new StringBuilder("Number of patients in database: "+database.size()); 
		for(Patient p : database)
			stringDB.append("\n"+p);
		
		return stringDB.toString();
	}
	
}
