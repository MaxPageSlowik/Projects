package group3.clinic.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.Visit;
import group3.util.Utility;

/**
 * @author: Group 3
 * ObjectSerializedList allow the clinic system to retrieve/save the database from/to object serialized file.
 */
public class ObjectSerializedList implements ListPersistenceObject {
	private String patientFilename;
	private String visitFilename; 
	
	/**
	 * Constructor for the ObjectSerializedList object
	 * parameters are the names of the files that will be created
	 * Creates serialized files of the object it is given.
	 * @param patientFilename
	 * @param visitFilename
	 */
	public ObjectSerializedList(String patientFilename, String visitFilename) {
		if (patientFilename == null || visitFilename == null)
			throw new NullPointerException("File name deos not exist");
		this.patientFilename = patientFilename;
		this.visitFilename = visitFilename;
	}
	
	/**
	 * Allows the creation of a serialized object from a sequential text file.
	 * Throws IOException if the argument file is not found.
	 * @param sequentialPatients
	 * @param sequentialVisits
	 * @throws IOException
	 */
	public void convertSequentialFilesToSerialized(String sequentialPatients, String sequentialVisits)
			throws IOException {
		SequentialTextFileList textFile = new SequentialTextFileList(sequentialPatients, sequentialVisits);
		// patients
		List<Patient> patients = textFile.getPatientDatabase();
		Utility.serializeObject(patients, patientFilename);
		

		List<Queue<Visit>> visits = textFile.getVisitDatabase();
		Utility.serializeObject(visits, visitFilename);
		
	}

	/**
	 * Reads from the serialized file created 
	 * returns a List<Patient>
	 */
	@Override
	public List<Patient> getPatientDatabase() {

		try {
			List<Patient> patient = (List<Patient>) Utility.deserializeObject(patientFilename);
			return patient;

		} catch (ClassNotFoundException | IOException e) {
			System.out.println(e.getMessage());
			return new ArrayList<Patient>();
		}
	}

	/**
	 * Reads from the visit serialized file
	 * returns List<Queue<Visit>> 
	 */
	@Override
	public List<Queue<Visit>> getVisitDatabase() {
	
		try{
			List<Queue<Visit>> q_visit = (List<Queue<Visit>>) Utility.deserializeObject(visitFilename);
			return q_visit;
		}catch(ClassNotFoundException | IOException e) {
			System.out.println(e.getMessage());
			return new ArrayList<Queue<Visit>>();
		}
	}

	/**
	 * Saves the patient list argument to a serialized file.
	 * @param patients
	 * @throws IOException
	 */
	@Override
	public void savePatientDatabase(List<Patient> patients) throws IOException {
		Utility.serializeObject(patients, patientFilename);
	}

	/**
	 * Saves the List<Queue<Visit>> argument to a serialized file.
	 * @param visits
	 * @throws IOException
	 */
	@Override
	public void saveVisitDatabase(List<Queue<Visit>> visits) throws IOException {
		Utility.serializeObject(visits, visitFilename);
	}

}
