package group3.clinic.data;

import java.io.File;
import java.nio.charset.Charset;

import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.Visit;
import group3.clinic.business.VisitSorter;
import group3.util.ListUtilities;

/**
 * @author Max Page-Slowik
 *	The SortMergeApp is used to acquire and sort the patients and visits text files
 *	save them in the directory under sorted having the name sorted next to them.
 *	Next each slew of sorted files are then merged to make one file for patients
 *	and one file for visits in the database directory.
 */
public class SortMergeApp {

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		File database = new File("datafiles/database");
		if (!database.exists())
			database.mkdir();
		File sorted = new File("datafiles/sorted");
		if (!sorted.exists())
			sorted.mkdir();
		
		
		Visit[] visit_list1, visit_list2, visit_list3, visit_list4, visit_list5, visit_list6, visit_list7, visit_list8,
				visit_list9, visit_list10, visit_list11, visit_list12, visit_list13, mergeVisits;
		
		Patient[] patient_list1, patient_list2, patient_list3, patient_list4, patient_list5, patient_list6,
				patient_list7, patient_list8, patient_list9, patient_list10, patient_list11, patient_list12,
				patient_list13, mergePatients;
		
		try{
			
			/*
			 * Load the individual patient.txt files from 1 through 13.
			 * Sorts them and adds them to a new file in the datafiles\sorted\ directory under a new file name.
			 */
			patient_list1 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients1.txt");
			ListUtilities.selectionSort(patient_list1, patient_list1.length);
			ListUtilities.saveListToTextFile(patient_list1, "./datafiles/sorted/sortedPatient1.txt", false, Charset.defaultCharset());
			
			patient_list2 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients2.txt");
			ListUtilities.selectionSort(patient_list2, patient_list2.length);
			ListUtilities.saveListToTextFile(patient_list2, "./datafiles/sorted/sortedPatient2.txt", false, Charset.defaultCharset());
			
			patient_list3 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients3.txt");
			ListUtilities.selectionSort(patient_list3, patient_list3.length);
			ListUtilities.saveListToTextFile(patient_list3, "./datafiles/sorted/sortedPatient3.txt", false, Charset.defaultCharset());
			
			patient_list4 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients4.txt");
			ListUtilities.selectionSort(patient_list4, patient_list4.length);
			ListUtilities.saveListToTextFile(patient_list4, "./datafiles/sorted/sortedPatient4.txt", false, Charset.defaultCharset());
			
			patient_list5 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients5.txt");
			ListUtilities.selectionSort(patient_list5, patient_list5.length);
			ListUtilities.saveListToTextFile(patient_list5, "./datafiles/sorted/sortedPatient5.txt", false, Charset.defaultCharset());
			
			patient_list6 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients6.txt");
			ListUtilities.selectionSort(patient_list6, patient_list6.length);
			ListUtilities.saveListToTextFile(patient_list6, "./datafiles/sorted/sortedPatient6.txt", false, Charset.defaultCharset());
			
			patient_list7 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients7.txt");
			ListUtilities.selectionSort(patient_list7, patient_list7.length);
			ListUtilities.saveListToTextFile(patient_list7, "./datafiles/sorted/sortedPatient7.txt", false, Charset.defaultCharset());
			
			patient_list8 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients8.txt");
			ListUtilities.selectionSort(patient_list8, patient_list8.length);
			ListUtilities.saveListToTextFile(patient_list8, "./datafiles/sorted/sortedPatient8.txt", false, Charset.defaultCharset());
			
			patient_list9 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients9.txt");
			ListUtilities.selectionSort(patient_list9, patient_list9.length);
			ListUtilities.saveListToTextFile(patient_list9, "./datafiles/sorted/sortedPatient9.txt", false, Charset.defaultCharset());
			
			patient_list10 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients10.txt");
			ListUtilities.selectionSort(patient_list10, patient_list10.length);
			ListUtilities.saveListToTextFile(patient_list10, "./datafiles/sorted/sortedPatient10.txt", false, Charset.defaultCharset());
			
			patient_list11 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients11.txt");
			ListUtilities.selectionSort(patient_list11, patient_list11.length);
			ListUtilities.saveListToTextFile(patient_list11, "./datafiles/sorted/sortedPatient11.txt", false, Charset.defaultCharset());
			
			patient_list12 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients12.txt");
			ListUtilities.selectionSort(patient_list12, patient_list12.length);
			ListUtilities.saveListToTextFile(patient_list12, "./datafiles/sorted/sortedPatient12.txt", false, Charset.defaultCharset());
			
			patient_list13 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients13.txt");
			ListUtilities.selectionSort(patient_list13, patient_list13.length);
			ListUtilities.saveListToTextFile(patient_list13, "./datafiles/sorted/sortedPatient13.txt", false, Charset.defaultCharset());
			
			//merge all the patients into the file patients under the database directory
			mergePatients = (Patient[])ListUtilities.merge(patient_list1, patient_list2, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list3, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list4, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list5, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list6, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list7, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list8, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list9, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list10, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list11, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list12, "./datafiles/duplicates.txt");
			mergePatients = (Patient[])ListUtilities.merge(mergePatients, patient_list13, "./datafiles/duplicates.txt");
			
			ListUtilities.saveListToTextFile(mergePatients, "./datafiles/database/patients.txt", false, Charset.defaultCharset());
			
			//Load Visit arrays with the text file.
			visit_list1 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits1.txt", patient_list1);
			ListUtilities.sort(visit_list1, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list1, "./datafiles/sorted/sortedVisits1.txt", false, Charset.defaultCharset());
			
			visit_list2 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits2.txt", patient_list2);
			ListUtilities.sort(visit_list2, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list2, "./datafiles/sorted/sortedVisits2.txt", false, Charset.defaultCharset());
			
			visit_list3 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits3.txt", patient_list3);
			ListUtilities.sort(visit_list3, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list3, "./datafiles/sorted/sortedVisits3.txt", false, Charset.defaultCharset());
			
			visit_list4 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits4.txt", patient_list4);
			ListUtilities.sort(visit_list4, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list4, "./datafiles/sorted/sortedVisits4.txt", false, Charset.defaultCharset());
			
			visit_list5 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits5.txt", patient_list5);
			ListUtilities.sort(visit_list5, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list5, "./datafiles/sorted/sortedVisits5.txt", false, Charset.defaultCharset());
			
			visit_list6 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits6.txt", patient_list6);
			ListUtilities.sort(visit_list6, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list6, "./datafiles/sorted/sortedVisits6.txt", false, Charset.defaultCharset());
			
			visit_list7 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits7.txt", patient_list7);
			ListUtilities.sort(visit_list7, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list7, "./datafiles/sorted/sortedVisits7.txt", false, Charset.defaultCharset());
			
			visit_list8 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits8.txt", patient_list8);
			ListUtilities.sort(visit_list8, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list8, "./datafiles/sorted/sortedVisits8.txt", false, Charset.defaultCharset());
			
			visit_list9 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits9.txt", patient_list9);
			ListUtilities.sort(visit_list9, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list9, "./datafiles/sorted/sortedVisits9.txt", false, Charset.defaultCharset());
			
			visit_list10 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits10.txt", patient_list10);
			ListUtilities.sort(visit_list10, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list10, "./datafiles/sorted/sortedVisits10.txt", false, Charset.defaultCharset());
			
			visit_list11 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits11.txt", patient_list11);
			ListUtilities.sort(visit_list11, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list11, "./datafiles/sorted/sortedVisits11.txt", false, Charset.defaultCharset());
			
			visit_list12 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits12.txt", patient_list12);
			ListUtilities.sort(visit_list12, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list12, "./datafiles/sorted/sortedVisits12.txt", false, Charset.defaultCharset());
			
			visit_list13 = ClinicFileLoader.getVisitListFromSequentialFile("../datafiles/visits13.txt", patient_list13);
			ListUtilities.sort(visit_list13, new VisitSorter()); // Sorting visits
			ListUtilities.saveListToTextFile(visit_list13, "./datafiles/sorted/sortedVisits13.txt", false, Charset.defaultCharset());
			
			//merge all the sorted visits into the visits text file in the database directory
			mergeVisits = (Visit[])ListUtilities.merge(visit_list1, visit_list2, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list3, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list4, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list5, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list6, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list7, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list8, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list9, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list10, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list11, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list12, "./datafiles/duplicates.txt");
			mergeVisits = (Visit[])ListUtilities.merge(mergeVisits, visit_list13, "./datafiles/duplicates.txt");
			
			ListUtilities.sort(mergeVisits, new VisitSorter());
			ListUtilities.saveListToTextFile(mergeVisits, "./datafiles/database/visits.txt", false, Charset.defaultCharset());
			
			
			
		}catch(Exception e){
			e.printStackTrace();
			
		}
		
		
		
	}

}
