package dw317.lib.medication;

public class DINMedicationTest {

	public static void main(String[] args) {
		DINMedication med1 = new DINMedication("12345678", "Vicks NyQuil"); // Should be good
		DINMedication med2 = new DINMedication(" 12345678", "Vicks NyQuil"); // Should be wrong
		DINMedication med3 = new DINMedication("12345678 ", "Vicks NyQuil"); // Should be wrong
		DINMedication med4 = new DINMedication("1-345678", "Vicks NyQuil"); // Should be wrong
		DINMedication med5 = new DINMedication("123456789", "Vicks NyQuil"); // Should be wrong
		DINMedication med6 = new DINMedication("1234567", "Vicks NyQuil"); // Should be wrong
		DINMedication med7 = new DINMedication(" 1234567", "Vicks NyQuil"); // Should be wrong
		DINMedication med8 = new DINMedication("1234567 ", "Vicks NyQuil"); // Should be wrong
		DINMedication med9 = new DINMedication("1234 567", "Vicks NyQuil"); // Should be wrong

	}

}
