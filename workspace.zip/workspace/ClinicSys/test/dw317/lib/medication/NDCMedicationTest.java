package dw317.lib.medication;

public class NDCMedicationTest {

	public static void main(String[] args) {
		NDCMedication med1 = new NDCMedication("49781-181-25", "Vicks NyQuil"); // Should be good
		NDCMedication med2 = new NDCMedication(" 49781-181-25", "Vicks NyQuil"); // Should be wrong
		NDCMedication med3 = new NDCMedication("49781-181-25 ", "Vicks NyQuil"); // Should be wrong
		NDCMedication med4 = new NDCMedication(" 9781-181-25", "Vicks NyQuil"); // Should be wrong
		NDCMedication med5 = new NDCMedication("49781-181-2 ", "Vicks NyQuil"); // Should be wrong
		NDCMedication med6 = new NDCMedication("49-81-181-25", "Vicks NyQuil"); // Should be wrong
		NDCMedication med7 = new NDCMedication("49781-181--5", "Vicks NyQuil"); // Should be wrong
		NDCMedication med8 = new NDCMedication("49781-181-251", "Vicks NyQuil"); // Should be wrong
		NDCMedication med9 = new NDCMedication("49781-181-2", "Vicks NyQuil"); // Should be wrong
		NDCMedication med10 = new NDCMedication("49781118112", "Vicks NyQuil"); // Should be wrong
		NDCMedication med11 = new NDCMedication("4-781-181-2", "Vicks NyQuil"); // Should be wrong

	}

}
