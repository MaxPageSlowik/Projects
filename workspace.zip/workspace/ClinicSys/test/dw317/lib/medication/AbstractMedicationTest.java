package dw317.lib.medication;

import dw317.lib.medication.Medication.Scheme;

public class AbstractMedicationTest {
	
	public static void main(String[] args) {
		//AbstractMedication med1 = new AbstractMedication(Medication.Scheme.NDC, "37000-812-08", "Vicks NyQuil");
		//AbstractMedication med2 = new AbstractMedication(Medication.Scheme.NDC, "37000-812-08", "Vicks NyQuil");
		//AbstractMedication med3 = new AbstractMedication(Medication.Scheme.NDC, "49781-081-25", "Adult Glycerin Laxative");

		//System.out.println("Med1:\n" + med1.toString() + "\n" + med1.hashCode() + "\n\nMed2:" + med2.toString() + "\n" + med2.hashCode() + "\n\nMed3:" + med3.toString() + "\n" + med3.hashCode());
	}

}
