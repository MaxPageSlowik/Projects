package dw317.lib.medication;

public class MedicationSchemeTest {

	public static void main(String[] args) {
		Medication.Scheme scheme = Medication.Scheme.NDC;

		System.out.println(scheme);
		
	}

}
