package group3.clinic.data;

import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.Visit;
import group3.clinic.business.VisitSorter;
import group3.util.ListUtilities;

public class VisitSorterTest {

	public static void main(String[] args) {
		// Try to load all the patient lists
		Patient[] patient_list1, patient_list2, patient_list3, patient_list4, patient_list5, patient_list6, patient_list7, patient_list8, patient_list9, patient_list10, patient_list11, patient_list12, patient_list13, patient_list14;

				
		// Try to load all the visits lists
		Visit[] visit_list1, visit_list2, visit_list3, visit_list4, visit_list5, visit_list6, visit_list7, visit_list8, visit_list9, visit_list10, visit_list11, visit_list12, visit_list13, visit_list14, visit_list15;

		
		try{	
			System.out.println("VISITS SORTED");
			System.out.println("FAILURES");
			// LOADING VISITS ARRAYS
			// DOES NOT WORK
			// "CASE: ./datafiles/visits14.txt" >> nothing should be initialized
			patient_list14 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patienst14.txt"); // File does not exist
			visit_list14 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits14.txt", patient_list14); // File does not exist
			ListUtilities.sort(visit_list14, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits14.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list14.length);
			// Print the array
			for(Visit visit: visit_list14){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits15.txt" >> nothing should be initialized because we are comparing the wrong arrays and it can't find a single match
			patient_list2 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients2.txt"); // Using patient_list2 for this case
			visit_list15 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits1.txt", patient_list2);
			ListUtilities.sort(visit_list15, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits1.txt + patient_list2 - SORTED BY PRIORITY" + " ENTRIES: " + visit_list15.length);
			// Print the array
			for(Visit visit: visit_list15){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			System.out.println("PASSES");
			// WORKS
			// "CASE: ./datafiles/visits1.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list1 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients1.txt");
			visit_list1 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits1.txt", patient_list1);
			ListUtilities.sort(visit_list1, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits1.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list1.length);
			// Print the array
			for(Visit visit: visit_list1){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits2.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list2 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients2.txt");
			visit_list2 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits2.txt", patient_list2);
			ListUtilities.sort(visit_list2, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits2.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list2.length);
			// Print the array
			for(Visit visit: visit_list2){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}

			System.out.println();
			
			// "CASE: ./datafiles/visits3.txt" >> everything should work - NEEDS TO RETURN 10 ENTRIES SORTED BY PRIORITY
			patient_list3 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients3.txt");
			visit_list3 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits3.txt", patient_list3);
			ListUtilities.sort(visit_list3, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits3.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list3.length);
			// Print the array
			for(Visit visit: visit_list3){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits4.txt" >> should skip over first line - NEEDS TO RETURN 4 ENTRIES BECAUSE RAMQS DO NOT MATCH AND THEREFORE SHOULD BE DISCARTED SORTED BY PRIORITY
			patient_list4 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients4.txt");
			visit_list4 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits4.txt", patient_list4);
			ListUtilities.sort(visit_list4, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits4.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list4.length);
			// Print the array
			for(Visit visit: visit_list4){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits5.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list5 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients5.txt");
			visit_list5 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits5.txt", patient_list5);
			ListUtilities.sort(visit_list5, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits5.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list5.length);
			// Print the array
			for(Visit visit: visit_list5){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits6.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list6 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients6.txt");
			visit_list6 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits6.txt", patient_list6);
			ListUtilities.sort(visit_list6, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits6.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list6.length);
			// Print the array
			for(Visit visit: visit_list6){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits7.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list7 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients7.txt");
			visit_list7 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits7.txt", patient_list7);
			ListUtilities.sort(visit_list7, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits7.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list7.length);
			// Print the array
			for(Visit visit: visit_list7){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits8.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES BECAUSE GASK85111884 IS MISSING FROM PATIENTS SORTED BY PRIORITY
			patient_list8 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients8.txt");
			visit_list8 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits8.txt", patient_list8);
			ListUtilities.sort(visit_list8, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits8.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list8.length);
			// Print the array
			for(Visit visit: visit_list8){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits9.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list9 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients9.txt");
			visit_list9 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits9.txt", patient_list9);
			ListUtilities.sort(visit_list9, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits9.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list9.length);
			// Print the array
			for(Visit visit: visit_list9){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits10.txt" >> should skip empty lines and give a fully loaded array - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list10 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients10.txt");
			visit_list10 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits10.txt", patient_list10);
			ListUtilities.sort(visit_list10, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits10.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list10.length);
			// Print the array
			for(Visit visit: visit_list10){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits11.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list11 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients11.txt");
			visit_list11 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits11.txt", patient_list11);
			ListUtilities.sort(visit_list11, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits11.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list11.length);
			// Print the array
			for(Visit visit: visit_list11){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits12.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list12 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients12.txt");
			visit_list12 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits12.txt", patient_list12);
			ListUtilities.sort(visit_list12, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits12.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list12.length);
			// Print the array
			for(Visit visit: visit_list12){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
			
			System.out.println();
			
			// "CASE: ./datafiles/visits13.txt" >> everything should work - NEEDS TO RETURN 8 ENTRIES SORTED BY PRIORITY
			patient_list13 = ClinicFileLoader.getPatientListFromSequentialFile("./datafiles/patients13.txt");
			visit_list13 = ClinicFileLoader.getVisitListFromSequentialFile("./datafiles/visits13.txt", patient_list13);
			ListUtilities.sort(visit_list13, new VisitSorter()); // Try to sort
			System.out.println("CASE: ./datafiles/visits13.txt - SORTED BY PRIORITY" + " ENTRIES: " + visit_list13.length);
			// Print the array
			for(Visit visit: visit_list13){
				System.out.println(	visit.getPatient().getRamq() + " " + 
									visit.getRegistrationDateAndTime() + " " + 
									visit.getTirageDateAndTime() + " " +
									visit.getPriority() + " " + 
									visit.getComplaint());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

}
