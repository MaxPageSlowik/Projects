package group3.clinic.data;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Optional;

import dw317.clinic.DefaultPatientVisitFactory;
import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.Visit;
import dw317.clinic.data.NonExistingPatientException;
import dw317.lib.medication.Medication;
import dw317.lib.medication.NDCMedication;
import group3.clinic.business.ClinicPatient;
import group3.clinic.business.Ramq;
import group3.clinic.business.VisitSorter;
import group3.util.ListUtilities;

/**
 * @author Jonathan Bizier
 *
 */

public class PatientListDBTest {

	public static void main(String[] args) {
		// Build the files
		setup(); // Load the test files with strings, reopen them, sort them and save them again. See modifications
		
		// Loading SequentialTextFileList	
		//SequentialTextFileList stfl = new SequentialTextFileList("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
		
		// Loading ObjectSerializedList
		ObjectSerializedList osl = new ObjectSerializedList("./testfiles/testPatients.ser",
				"./testfiles/testVisits.ser");
		
		// Test cases
		// Single constructor
		PatientListDB patientdb_single = new PatientListDB(osl);
		System.out.println("-->Single Constructor:");
		System.out.println(patientdb_single.toString()); // Testing the toString()
		
		// Tearing down the test files
		teardown();
		
		// Done the first constructor, tearing down for specs and rebuilding
		
		setup(); // Load the test files with strings, reopen them, sort them and save them again. See modifications
		
		// Loading SequentialTextFileList
		//stfl = new SequentialTextFileList("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
		
		// Double constructor		
		PatientListDB patientdb_double = new PatientListDB(osl, DefaultPatientVisitFactory.DEFAULT);
		System.out.println("\n-->Double Constructor:");
		System.out.println(patientdb_double.toString()); // Testing the toString()
		
		// Tearing down the test files
		teardown();
		
		// Done the double param constructor now doing the method tests
		// Testing the methods of PatientListDB
		
		setup(); // Load the test files with strings, reopen them, sort them and save them again. See modifications
		
		// Loading SequentialTextFileList
		//stfl = new SequentialTextFileList("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
		
		PatientListDB patientdb_methods = new PatientListDB(osl);
		
		// add(Patient aPatient) throws DuplicatePatientException
		try{
			patientdb_methods.add(new ClinicPatient("Patrick", "Nolin", "NOLP05051801")); // PASS
			System.out.println("\n-->ADDING PATIENT NOLP05051801:\n" + patientdb_methods.toString()); // Print to see added patient in right spot
			System.out.println("-->ADDING PATIENT NOLP05051801:");
			patientdb_methods.add(new ClinicPatient("Patrick", "Nolin", "NOLP05051801")); // FAIL SINCE DUPLICATE
			
		}catch(Exception nepe){
			System.out.println(nepe);
		}
		
		// disconnect() throws IOException
		try{
			patientdb_methods.disconnect(); // PASS 
			System.out.println("\n-->DISCONNECTING DATABASE:\n" + patientdb_methods); // Should return null since database gets disconnected
			System.out.println("-->DISCONNECTING DATABASE:");
			patientdb_methods.disconnect(); // FAIL SINCE DATABASE IS ALREADY DISCONNECTED
			
		}catch(IOException ioe){
			System.out.println(ioe);
		}
		
		// Tearing down the test files
		teardown();
		
		// Refilling database after disconnection
		setup(); // Load the test files with strings, reopen them, sort them and save them again. See modifications
		
		// Loading SequentialTextFileList
		//stfl = new SequentialTextFileList("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
		
		patientdb_methods = new PatientListDB(osl);
		
		// getPatient(Ramq ramq) throws NonExistingPatientException
		try{
			System.out.println("\n-->GETTING PATIENT HUNM89031203:");
			System.out.println(patientdb_methods.getPatient(new Ramq("HUNM89031203"))); // PASS
			System.out.println("-->GETTING PATIENT HUNM89031201:");
			System.out.println(patientdb_methods.getPatient(new Ramq("HUNM89031201"))); // FAIL SINCE IT CANNOT FIND THE PATIENT
		}catch(NonExistingPatientException nepe){
			System.out.println(nepe);
		}
		
		// exists(Ramq ramq)
		System.out.println("\n-->PATIENT HUNM89031203 EXISTS:\n" + patientdb_methods.exists(new Ramq("HUNM89031203"))); // PASS
		System.out.println("-->PATIENT HUNM89031201 EXISTS:\n" + patientdb_methods.exists(new Ramq("HUNM89031201"))); // FAIL SINCE IT CANNOT FIND THE PATIENT
		
		// getPatientsPrescribed(Medication medication)
		System.out.println("\n-->LOOKING FOR PATIENTS USING MEDICATION NDC*37000-812-08*Vicks NyQuil:\n" + patientdb_methods.getPatientsPrescribed(
				Medication.getInstance(Medication.Scheme.NDC, "37000-812-08", "Vicks NyQuil"))); // PASS AND RETURNS 2 CATHERINE AND MICHAEL
		
		System.out.println("-->LOOKING FOR PATIENTS USING MEDICATION DIN*00863270*Tylenol Extra Strength:\n" + patientdb_methods.getPatientsPrescribed(
				Medication.getInstance(Medication.Scheme.DIN, "00863270", "Tylenol Extra Strength"))); // EMPTY SINCE THERE IS NO ONE WITH THAT MEDICATION
		
		// update(Patient modifiedPatient) throws NonExistingPatientException
		try{
			// Making new patient and changing its parameters
			ClinicPatient mod_patient = new ClinicPatient("Michael", "Hunt", "HUNM89031203");
			mod_patient.setExistingConditions(Optional.ofNullable("Dead on arrival"));
			System.out.println("\n-->MODIFYING HUNM89031203 TO DEAD ON ARRIVAL:");
			
			patientdb_methods.update(mod_patient); // PASS
			
			System.out.println(patientdb_methods.toString()); // Printing update
			
			// Making new patient and changing its parameters
			mod_patient = new ClinicPatient("Zidane", "Beckham", "BECZ84120310");
			mod_patient.setExistingConditions(Optional.ofNullable("Dead on arrival"));
			System.out.println("-->MODIFYING BECZ84120310:");
			
			patientdb_methods.update(mod_patient); // FAIL SINCE IT CANNOT FIND PATIENT
			
		}catch(NonExistingPatientException nepe){
			System.out.println(nepe);
		}
		
		// testing if the .getPatientDatabase returns the appropriate data.
		List<Patient> listofp; 
		listofp = osl.getPatientDatabase();
		System.out.println("\nTESTING .getPatientDatabase() METHOD:\n" + listofp.toString());
		
		// test if the .savePatientDatabase works and opening it again to make sure the contents are consistent
		try{
			System.out.println("\nSAVING PATIENT LIST USING .savePatientDatabase() METHOD");
			osl.savePatientDatabase(listofp);
			listofp = osl.getPatientDatabase();
			System.out.println("PRINTING PATIENT DATABASE FROM FILE SAVED:\n" + listofp.toString());
		}
		catch(IOException e){
			System.out.println(e.getMessage());
		}
		
		// Tearing down the test files
		teardown();
	}
	
	private static void setup() {
		Patient[] patient_list_test; // Patient test list
		Visit[] visit_list_test; // Visit test list
		ObjectSerializedList osl = new ObjectSerializedList("./testfiles/testPatients.ser",
				"./testfiles/testVisits.ser");
		
		String[] patients = new String[11];
		patients [0] = "HUNM89031203*Michael*Hunt*5142344747*NDC*37000-812-08*Vicks NyQuil*Pneumonia";
		patients [1] = "SHNJ78042312*John*Shnaucker*4387381122*NDC*49781-081-25*Adult Glycerin Laxative*Dehydration";
		patients [2] = "ESCP87061943*Pablo*Escobar*4503841662*NDC*0527-1728-74*Cocaine Hydrochloride*Broken Femur";
		patients [3] = "FRAC67542085*Crystale*Fratch*4384828374*NDC*50580-451-03*TYLENOL*Severe Migraine";
		patients [4] = "CANA76080309*Anders*Canters*5148568273*NDC*0280-8005-40*Midol Complete*Back Pain";
		patients [5] = "CASJ78010619*Justin*Case*5145817777*NDC*58232-0750-2*BENADRYL Extra Strength Itch Cooling*Poison Ivy";
		patients [6] = "REDC60582753*Claire*Redfield*4502938133*NDC*55714-4589-1*Cataracts*Cataracts";
		patients [7] = "KEEK98581764*Kappa*Keepo*3489482711*NDC*58394-634-03*BeneFIX*Hemophilia";
		patients [8] = "GASK85111884*Krey*Gasm*5144781827*NDC*45865-356-90*Gabapentin*Concussion";
		patients [9] = "DEVR74570194*Rashanda*Devil*5148481889*NDC*44567-804-01*Piperacillin and Tazobactam*Appendicitis";
		patients [10] = "DICA30600407*Catherine*Di*5144473625*NDC*37000-812-08*Vicks NyQuil*Back pain";


		String[] visits = new String[10];
		visits [0] = "HUNM89031203*2010*09*13*13*30*2015*09*09*13*14*2*SOAR THROAT";
		visits [1] = "SHNJ78042312*2001*06*19*12*15*******MILD BLEEDED OF INTERNAL ORGANS";
		visits [2] = "ESCP87061943*1998*12*13*15*21*2012*01*12*11*05*4*CHEST PAIN";
		visits [3] = "FRAC67542085*1972*07*21*08*20*2010*12*22*07*05*2*FEVER";
		visits [4] = "CANA76080309*2015*09*09*13*24*******ARM PAIN";
		visits [5] = "CASJ78010619*2015*08*01*14*30*2015*09*01*14*40*1*BROKEN FINGER";
		visits [6] = "REDC60582753*1992*10*10*09*35*2013*08*10*16*01*2*LOW BLOOD PRESSURE";
		visits [7] = "KEEK98581764*2001*05*21*13*15*2006*06*06*18*06*5*GUN SHOOT WOUND";
		visits [8] = "GASK85111884*2015*12*21*06*00*******BROKEN NOSE";
		visits [9] = "DEVR74570194*2001*10*02*10*02*2015*08*12*13*15*3*STOMATCH PAIN";
		
		File dir = new File("testfiles");
		try{
			if (!dir.exists()){  
				dir.mkdirs();
			}
			
			ListUtilities.saveListToTextFile(patients, "./testfiles/testPatients.txt"); // Saving the lists from strings
			ListUtilities.saveListToTextFile(visits, "./testfiles/testVisits.txt"); // Saving the lists from strings
			
			// Loading them into patient and visit lists to sort them and save them again
			patient_list_test = ClinicFileLoader.getPatientListFromSequentialFile("./testfiles/testPatients.txt"); // Load built patient file
			visit_list_test = ClinicFileLoader.getVisitListFromSequentialFile("./testfiles/testVisits.txt", patient_list_test); // Load built visit file

			ListUtilities.selectionSort(patient_list_test, patient_list_test.length); // Sorting patients
			ListUtilities.sort(visit_list_test, new VisitSorter()); // Sorting visits
			
			ListUtilities.saveListToTextFile(patient_list_test, "./testfiles/testPatients.txt", false, Charset.defaultCharset()); // Save the sorted patients again for test cases
			ListUtilities.saveListToTextFile(visit_list_test, "./testfiles/testVisits.txt", false, Charset.defaultCharset()); // Save the sorted visits again for the test cases
			
			osl.convertSequentialFilesToSerialized("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
			
		}
		catch(IOException io){
			System.out.println
			("Error creating file in setUp()");
		}
	}
	
	private static void teardown() {
		File theFile = new File("testfiles/testPatients.txt");
		if (theFile.exists()) {
			theFile.delete();
		}
		theFile = new File("testfiles/testVisits.txt");
		if (theFile.exists()) {
			theFile.delete();
		}
	}

}
