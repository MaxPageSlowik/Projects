package group3.clinic.data;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Optional;
import java.util.Queue;

import dw317.clinic.DefaultPatientVisitFactory;
import dw317.clinic.business.interfaces.Patient;
import dw317.clinic.business.interfaces.Visit;
import group3.clinic.business.VisitSorter;
import group3.util.ListUtilities;
import group3.clinic.business.*;

public class VisitQueueDBTest {

	public static void main(String[] args) {
		// Build the files
		System.out.println("ran setup()\n");
		setup(); // Load the test files with strings, reopen them, sort them and save them again. See modifications
		
		// Loading database
		//SequentialTextFileList stfl = new SequentialTextFileList("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
		
		// Loading ObjectSerializedList
				ObjectSerializedList osl = new ObjectSerializedList("./testfiles/testPatients.ser",
						"./testfiles/testVisits.ser");
		
		// Test cases
		// Single constructor
		VisitQueueDB visitdb_single = new VisitQueueDB(osl);
		System.out.println("Single Constructor");
		System.out.println(visitdb_single.toString()); // Testing the toString()
		
		// Tearing down the test files
		System.out.println("ran teardown()\n");
		teardown();
		
		// Done the first constructor, tearing down for specs and rebuilding
		
		System.out.println("ran setup()");
		setup(); // Load the test files with strings, reopen them, sort them and save them again. See modifications
		
		// Loading database
		//stfl = new SequentialTextFileList("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
		
		// Double constructor		
		VisitQueueDB visitdb_double = new VisitQueueDB(osl, DefaultPatientVisitFactory.DEFAULT);
		System.out.println("\nDouble Constructor");
		System.out.println(visitdb_double.toString()); // Testing the toString()
		
		// Tearing down the test files
		System.out.println("ran teardown()");
		teardown();
		
		// Testing the methods of VisitQueueDB
		System.out.println("ran setup()");
		setup();
		
		//stfl = new SequentialTextFileList("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
		VisitQueueDB visitdb_methods = new VisitQueueDB(osl, DefaultPatientVisitFactory.DEFAULT);
		// Test the add method
		ClinicVisit cv = new ClinicVisit(new ClinicPatient("James","Dean","DEAJ42030418"));
		visitdb_methods.add(cv);//Successfully adds to the database at the right place
		System.out.println("\nAdded James Dean to the database at the end of the proper queue\n");
		System.out.println(visitdb_methods.toString());
		//Test the remove method
		System.out.println("\nRemoving "+visitdb_methods.getNextVisit(Priority.NOTURGENT).orElse(null)+"\n");
		visitdb_methods.remove(Priority.NOTURGENT);//Should be gone
		
		System.out.println(visitdb_methods.toString());
		//test the disconnect methods
		try{
			visitdb_methods.disconnect(); // PASS 
			System.out.println("\n-->DISCONNECTING DATABASE:\n" + visitdb_methods); // Should return null since database gets disconnected
			System.out.println("-->DISCONNECTING DATABASE:");
			visitdb_methods.disconnect(); // FAIL SINCE DATABASE IS ALREADY DISCONNECTED
			
		}catch(IOException ioe){
			System.out.println(ioe);
		}
		
		System.out.println("ran teardown()\n");
		teardown();
		// Testing the getNextVisit
		System.out.println("ran setup()");
		setup();
		try {
			// stfl = new SequentialTextFileList("./testfiles/testPatients.txt",
			// "./testfiles/testVisits.txt");
			VisitQueueDB visitdb_method = new VisitQueueDB(osl, DefaultPatientVisitFactory.DEFAULT);
			// check the next visit
			Visit v = visitdb_method.getNextVisit(Priority.NOTASSIGNED).orElse(null);
			Visit v2 = visitdb_method.getNextVisit(Priority.REANIMATION).orElse(null);
			System.out.println("Searched for the first not assigned property " + v);
			System.out.println("Searched for the first reanimation property " + v2);

			// check the size of the not assigned queue
			System.out.println("\nThe size of the not assigned queue is " + visitdb_method.size(Priority.NOTASSIGNED));

			// change the priority code
			System.out.println("\nChanging the priorty code for first not assigned patient");
			visitdb_method.update(Priority.URGENT, Priority.REANIMATION);
			System.out.println(visitdb_method.toString());

			visitdb_method.update(Priority.URGENT, Priority.REANIMATION);
			System.out.println(visitdb_method.toString());

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		// testing if the .getPatientDatabase returns the appropriate data.
		List<Queue <Visit>> listofv; 
		listofv = osl.getVisitDatabase();
		System.out.println("\nTESTING .getVisitDatabase() METHOD:\n" + listofv.toString());
		
		// test if the .savePatientDatabase works and opening it again to make sure the contents are consistent
		try{
			System.out.println("\nSAVING VISIT LIST USING .saveVisitDatabase() METHOD");
			osl.saveVisitDatabase(listofv);
			listofv = osl.getVisitDatabase();
			System.out.println("PRINTING VISIT DATABASE FROM FILE SAVED:\n" + listofv.toString());
		}
		catch(IOException e){
			System.out.println(e.getMessage());
		}
		
		teardown();
	}
	
	private static void setup() {
		Patient[] patient_list_test; // Patient test list
		Visit[] visit_list_test; // Visit test list
		ObjectSerializedList osl = new ObjectSerializedList("./testfiles/testPatients.ser",
				"./testfiles/testVisits.ser");
		
		String[] patients = new String[10];
		patients [0] = "HUNM89031203*Michael*Hunt*5142344747*NDC*37000-812-08*Vicks NyQuil*Pneumonia";
		patients [1] = "SHNJ78042312*John*Shnaucker*4387381122*NDC*49781-081-25*Adult Glycerin Laxative*Dehydration";
		patients [2] = "ESCP87061943*Pablo*Escobar*4503841662*NDC*0527-1728-74*Cocaine Hydrochloride*Broken Femur";
		patients [3] = "FRAC67542085*Crystale*Fratch*4384828374*NDC*50580-451-03*TYLENOL*Severe Migraine";
		patients [4] = "CANA76080309*Anders*Canters*5148568273*NDC*0280-8005-40*Midol Complete*Back Pain";
		patients [5] = "CASJ78010619*Justin*Case*5145817777*NDC*58232-0750-2*BENADRYL Extra Strength Itch Cooling*Poison Ivy";
		patients [6] = "REDC60582753*Claire*Redfield*4502938133*NDC*55714-4589-1*Cataracts*Cataracts";
		patients [7] = "KEEK98581764*Kappa*Keepo*3489482711*NDC*58394-634-03*BeneFIX*Hemophilia";
		patients [8] = "GASK85111884*Krey*Gasm*5144781827*NDC*45865-356-90*Gabapentin*Concussion";
		patients [9] = "DEVR74570194*Rashanda*Devil*5148481889*NDC*44567-804-01*Piperacillin and Tazobactam*Appendicitis";


		String[] visits = new String[10];
		visits [0] = "HUNM89031203*2010*09*13*13*30*2015*09*09*13*14*2*SOAR THROAT";
		visits [1] = "SHNJ78042312*2001*06*19*12*15*******MILD BLEEDED OF INTERNAL ORGANS";
		visits [2] = "ESCP87061943*1998*12*13*15*21*2012*01*12*11*05*4*CHEST PAIN";
		visits [3] = "FRAC67542085*1972*07*21*08*20*2010*12*22*07*05*4*FEVER";
		visits [4] = "CANA76080309*2015*09*09*13*24*******ARM PAIN";
		visits [5] = "CASJ78010619*2015*08*01*14*30*2015*09*01*14*40*5*BROKEN FINGER";
		visits [6] = "REDC60582753*1992*10*10*09*35*2013*08*10*16*01*4*LOW BLOOD PRESSURE";
		visits [7] = "KEEK98581764*2001*05*21*13*15*2006*06*06*18*06*1*GUN SHOOT WOUND";
		visits [8] = "GASK85111884*2015*12*21*06*00*******BROKEN NOSE";
		visits [9] = "DEVR74570194*2001*10*02*10*02*2015*08*12*13*15*3*STOMATCH PAIN";
		
		File dir = new File("testfiles");
		try{
			if (!dir.exists()){  
				dir.mkdirs();
			}
			
			ListUtilities.saveListToTextFile(patients, "testfiles/testPatients.txt"); // Saving the lists from strings
			ListUtilities.saveListToTextFile(visits, "testfiles/testVisits.txt"); // Saving the lists from strings
			
			// Loading them into patient and visit lists to sort them and save them again
			patient_list_test = ClinicFileLoader.getPatientListFromSequentialFile("./testfiles/testPatients.txt"); // Load built patient file
			visit_list_test = ClinicFileLoader.getVisitListFromSequentialFile("./testfiles/testVisits.txt", patient_list_test); // Load built visit file

			ListUtilities.selectionSort(patient_list_test, patient_list_test.length); // Sorting patients
			ListUtilities.sort(visit_list_test, new VisitSorter()); // Sorting visits
			
			ListUtilities.saveListToTextFile(patient_list_test, "./testfiles/testPatients.txt", false, Charset.defaultCharset()); // Save the sorted patients again for test cases
			ListUtilities.saveListToTextFile(visit_list_test, "./testfiles/testVisits.txt", false, Charset.defaultCharset()); // Save the sorted visits again for the test cases
			
			osl.convertSequentialFilesToSerialized("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
		}
		catch(IOException io){
			System.out.println
			("Error creating file in setUp()");
		}
	}
	
	private static void teardown() {
		File theFile = new File("testfiles/testPatients.txt");
		if (theFile.exists()) {
			theFile.delete();
		}
		theFile = new File("testfiles/testVisits.txt");
		if (theFile.exists()) {
			theFile.delete();
		}
	}
}
