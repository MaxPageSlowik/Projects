package group3.clinic.data;

import java.io.IOException;
import java.util.List;

import dw317.clinic.business.interfaces.Patient;

public class ObjectSerializedListTest {

	public static void main(String[] args) {
		
		// Creating an ObjectSerializedList, to use on the test cases.
		ObjectSerializedList osl = new ObjectSerializedList("./testfiles/testPatients.ser",
				"./testfiles/testVisits.ser");

		// Creating a SequentialTextFileList to use for the test case.
		SequentialTextFileList stfl = new SequentialTextFileList("./datafiles/sorted/sortedPatient3.txt",
				"./datafiles/sorted/sortedVisits3.txt");

		// Creating List<Patient> to print the initial file to test and compare
		// to the serialized, the deserialized file.
		List<Patient> orig_pat = stfl.getPatientDatabase();
		for (Patient i : orig_pat)
			System.out.println("print original\t\t " + i.toString());

		System.out.println("");

		// Doing initial serialization to test the method
		try {
			osl.convertSequentialFilesToSerialized("./datafiles/sorted/sortedPatient3.txt",
					"./datafiles/sorted/sortedVisits3.txt");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
		// putting the deserialized file to a list for printing.
		List<Patient> pat_de = (List<Patient>) osl.getPatientDatabase();
		for (Patient i : pat_de)
			System.out.println("print deserialized\t " + i.toString());

		// Using compareTo to view if the two strings are exactly the same.
		if (pat_de.toString().compareTo(orig_pat.toString()) == 0)
			System.out.println("\nThe two strings are the same");

	}
}
