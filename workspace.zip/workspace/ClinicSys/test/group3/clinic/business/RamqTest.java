package group3.clinic.business;

import dw317.lib.Name;

public class RamqTest {

	public static void main(String[] args) {
		Name myName = new Name("EVAN", "GLICAKIS");
		//Working ramq object.
		Ramq evanRamq = new Ramq("GLIE94101017", myName);
		System.out.println(evanRamq);
		
		//ramq(String s) test, should work.
		Ramq ramq1 = new Ramq("GLIE94101017");
		System.out.println(ramq1);

		// Test name characters, should work.
		Name testName = new Name("MA'X", "PAGE-SLOWIK");
		Ramq testRamq = new Ramq("PAGM97051217", testName);
		System.out.println(testRamq);
		
		// Should work, valid birthdate.
		Ramq ramq3 = new Ramq("123494101022");
		System.out.println(ramq3);
		
		Ramq nullRamq = new Ramq(null, myName);
		
		//Should not work, bithdate not valid.
		Ramq ramq2 = new Ramq("123456781111");
		System.out.println(ramq2);
		
		//Should not work, date out of date, name does not match.
		Ramq fakeEvanRamq = new Ramq ("GLYY99887766", myName);
		System.out.println(fakeEvanRamq);
		
		Name badName = new Name("1554" , "smith");
		
		//Should not work. Name does not match Ramq.
		Ramq badRamq = new Ramq("GLIE10109417", badName);
		System.out.println(badRamq);
		
		
		
		
	}
}
