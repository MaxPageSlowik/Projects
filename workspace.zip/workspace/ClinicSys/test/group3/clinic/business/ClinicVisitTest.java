/**
 * 
 */
package group3.clinic.business;

import java.util.Optional;
import java.time.LocalDateTime;
import dw317.clinic.business.interfaces.Patient;

/**
 * @author Max Page-Slowik
 *
 */
public class ClinicVisitTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Patient evan = new ClinicPatient("Evan", "Glicakis", "GLIE94101017");
			ClinicVisit ev = new ClinicVisit(evan);
			ev.setComplaint(Optional.ofNullable("Severe Dysentary"));
			ev.setPriority(Priority.VERYURGENT);
			ev.setRegistrationDateAndTime(2015, 05, 12, 12, 30);
			ev.setTriageDateAndTime(Optional.ofNullable(LocalDateTime.now()));
			
			/**
			 * Setting the triage time to before the registration time to gt the exception
			 * ev.setRegistrationDateAndTime(Optional.ofNullable(LocalDateTime.now()));
			 * ev.setTriageDateAndTime(2014, 5, 12, 12, 30);
			 */
			System.out.print(ev);
	}

}
