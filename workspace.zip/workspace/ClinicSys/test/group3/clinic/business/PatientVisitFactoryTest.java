/**
 * 
 */
package group3.clinic.business;

/**
 * @author Max
 *
 */
public class PatientVisitFactoryTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		

	}

}
