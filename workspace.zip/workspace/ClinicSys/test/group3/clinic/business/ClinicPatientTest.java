package group3.clinic.business;

import java.time.LocalDate;
import java.util.Optional;

import dw317.lib.Name;
import dw317.lib.medication.Medication;

public class ClinicPatientTest {

	public static void main(String[] args) {
		ClinicPatient evan = new ClinicPatient("EVAN", "GLICAKIS", "GLIE94101017");
		ClinicPatient max = new ClinicPatient("MAX", "PAGE-SLOWIK", "PAGM97051217");
		ClinicPatient jules = new ClinicPatient("Juliette","O'Hara", "OHAJ96561207");
		ClinicPatient johndoe = new ClinicPatient(null,null,null);
		// john for some reson likes numbers in his name, it doesn't work
		//ClinicPatient john = new ClinicPatient("73J","Jjdhf","JJkos95469456");
		
		Name name = evan.getName();
		Ramq rm = evan.getRamq();
		evan.setTelephoneNumber(Optional.ofNullable("5147567655"));
		evan.setExistingConditions(Optional.ofNullable("Cold"));
		LocalDate bDay = evan.getBirthday();
		evan.setMedication(Optional.ofNullable(Medication.getInstance(Medication.Scheme.NDC, "37000-812-08", "Vicks NyQuil")));
		String med = evan.getExistingConditions();
		Medication medication = evan.getMedication().orElse(null);
		
		String hd = "headache";
		max.setExistingConditions(Optional.ofNullable(hd));
		
		System.out.println(evan+"\n"+name+"\n"+rm+"\n"+med+"\n"+bDay+"\n"+medication);
		System.out.println(max);
		System.out.println(jules);
		System.out.println(johndoe);
		//System.out.println(john);
		
		
	}

}
