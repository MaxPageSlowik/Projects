/**
 * 
 */
package group3.dawsonclinic;

import dw317.clinic.business.interfaces.Visit;
import group3.clinic.data.SequentialTextFileList;
import group3.clinic.data.VisitQueueDB;

/**
 * @author Max
 *
 */
public class DawsonClinicPriorityPolicyTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SequentialTextFileList stfl = new SequentialTextFileList("./testfiles/testPatients.txt", "./testfiles/testVisits.txt");
		Visit visit;
		VisitQueueDB visitDB = new VisitQueueDB(stfl);
		DawsonClinicPriorityPolicy dcpp = new DawsonClinicPriorityPolicy(visitDB);
		try{
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		visit = dcpp.getNextVisit().orElse(null);
		System.out.println(visit.toString());
		}
		catch (NullPointerException npe){
			System.out.println("The database is empty");
		}
		
	}

}
