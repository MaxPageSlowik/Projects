package dw317.lib;

import java.io.Serializable;

/**
 * @author Max Page-Slowik
 *
 */
public class Name implements Comparable<Name>, Serializable {
	private String firstName;
	private String lastName;
	@SuppressWarnings("unused")
	private static final long serialVersionUID = 42031768871L;

	public Name() {
		firstName = "";
		lastName = "";
	}

	public Name(String firstName, String lastName) {
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFullName() {
		return firstName + " " + lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}
	
	@Override
	public String toString(){
		return firstName+ " " + lastName;
	}
	
	@Override
	public int compareTo(Name name) {
		if (this == name)
			return 0;
		if (this.lastName.equals(name.lastName))
			if (this.firstName.equals(name.firstName))
				return 0;
			else if (this.firstName.compareToIgnoreCase(name.firstName) > 0)
				return 1;
			else
				return -1;
		if (this.lastName.compareToIgnoreCase(name.lastName) > 0)
			return 1;
		else
			return -1;
	}
}