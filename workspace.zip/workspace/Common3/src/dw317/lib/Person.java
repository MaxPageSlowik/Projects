package dw317.lib;

public class Person {
	Name name;
	Address address;
	
	public Person(String firstName, String lastName){
		this.name= new Name(firstName, lastName);
		this.address = new Address();
	}
	
	public Person(String firstName, String lastName, Address address){
		this.name = new Name(firstName, lastName);
		this.address = address;
	}
	
	public Address getAddress(){
		Address add = this.address; 
		return add;
				
	}
	
	public Name getName(){
		Name n = this.name;
		return n;
	}
	
	public void setName(String firstName, String lastName){
		this.name = new Name(firstName, lastName);
	}
	
	public void setAddress(Address address){
		this.address = address;
	}
	
	@Override
	public String toString() {
            return name.toString() + "*" + 
            		(address == null ? ""  : 
            				address.toString());                      
	}



}
