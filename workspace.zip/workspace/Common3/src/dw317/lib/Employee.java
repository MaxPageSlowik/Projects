package dw317.lib;

public class Employee {
	private String emp_id;
	private Name name;
	
	public Employee (Name n, String emp_id){
		name = n;
		this.emp_id = emp_id;
	}
	
	public String getEmpId(){
		return emp_id;
	}
	
	public void setEmpId(String s){
		if(s != null && s.length() > 1)
			this.emp_id = s;
		else
			throw new IllegalArgumentException();
	}
	
	
}
