package dw317.lib;

public enum Gender {
	FEMALE, MALE
}
