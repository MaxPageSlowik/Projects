/**
 * 
 */
package group3.util;
import java.io.IOException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author group3
 *
 */
public class Utility {

	 public Utility(){
	 }
	 /**
	  * 
	  * @param object object to be serialized
	  * @param fileSpecification file where the serialized object will be put
	  * @throws IOException if the file could not be reached or any other io issue
	  */
	 public static void serializeObject	(Object object, 
				String fileSpecification) throws IOException   {
				ObjectOutputStream out = null;
				try 	{
					out = new ObjectOutputStream (
						new FileOutputStream (fileSpecification));

					out.writeObject (object);

				}
				catch (IOException e){
					//normally the exception would be logged to file then thrown
					throw new IOException ("Error serializing object to \n" +
						fileSpecification  + " " + e);
				}
				finally 	{
					if (out != null)
						out.close ();
				}
		    }
	 /**
	  * Deserializes the file given and returns the object from that file
	  * @param fileSpecification file for deserialization.
	  * @return the object that the file contains.
	  * @throws IOException file cannot be found or any other io problem
	  * @throws ClassNotFoundException there is no object within the file
	  */
	 public static Object deserializeObject (String fileSpecification)
				throws IOException, ClassNotFoundException {

				ObjectInputStream in = null;
				try {
					Object obj = null;
					in = new ObjectInputStream
					(new FileInputStream (fileSpecification));
					if (in != null)
						obj = in.readObject ();

					return obj;
				}
				catch (ClassNotFoundException | IOException e)
				{
					//normally the exception would be logged to file then thrown
					throw new IOException ("Error deserializing object from " +
					   fileSpecification + "\n" + e);
				}
				finally
				{
					if (in != null)
						in.close ();
				}
		    }
	 /**
	  * Returns a deep copy vis serialization of the object
	  * writing to memory and then returning the value in memory
	  * to a new object and returning that.
	  * @param obj the object you want copied
	  * @return a deep copy of the object you wanted copied
	  */
	 public static <T> T copyOf (T obj){
		 try{
			 ByteArrayOutputStream baos = new ByteArrayOutputStream();
			 ObjectOutputStream out = new ObjectOutputStream(baos);
			 out.writeObject(obj);
			 out.close();
			 
			 ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
			 ObjectInputStream in = new ObjectInputStream(bais);
			 @SuppressWarnings("unchecked")
			 	T read = (T)in.readObject();
			 in.close();
			 return read;
		 }
		 catch(ClassNotFoundException | IOException e){
			 throw new IllegalArgumentException("Can't be"
			 		+ "serialized or deserialized"+ obj);
		 }
	 }
}
