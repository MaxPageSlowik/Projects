package group3.util;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Comparator;

public class ListUtilities {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void selectionSort(Comparable[] list, int size) {
		int small = 0;
		Comparable temp;
		for (int i = 0; i < size - 1; i++) {
			small =i;
			for (int j = (i + 1); j < size; j++) {
				if (list[j].compareTo(list[small]) < 0) {
					small = j;
				}
			}
			temp = list[i];
			list[i] = list[small];
			list[small] = temp;
		}
	}

	/**
	 * @returns a merged array of the comparable object type
	 * @param list1
	 *            first array of comparable objects to be merged list2 second
	 *            array of comparable objects to be merged duplicateFileName
	 *            filename for any duplicates of patients or visits
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static Comparable[] merge(Comparable[] list1, Comparable[] list2, String duplicateFileName)
			throws IOException {
		int i = 0;
		int j = 0;
		int k = 0;

		Comparable[] list3 = (Comparable[]) Array.newInstance(list1.getClass().getComponentType(),
				(list1.length + list2.length));
		String[] mergeList = new String[(list1.length + list2.length)];
		for (; k < (list1.length + list2.length) && i < list1.length && j < list2.length; k++) {

			if (list1[i].compareTo(list2[j]) < 0) {
				list3[k] = list1[i];
				i++;
			}

			else if (list1[i].compareTo(list2[j]) > 0) {
				list3[k] = list2[j];
				j++;
			}

			else if (list1[i].compareTo(list2[j]) == 0) {
				list3[k] = list1[i];
				mergeList[k] = (list3[k] + " (merged)");
				i++;
				k++;
				list3[k] = list1[j];
				mergeList[k] = (list3[k].toString());
				j++;

			}

		}

		for (; i < list1.length; k++) {
			list3[k] = list1[i];
			i++;

		}

		for (; j < list2.length; k++) {
			list3[k] = list2[j];
			j++;

		}
		saveListToTextFile(mergeList, duplicateFileName, true, Charset.defaultCharset());
		return list3;
	}

	/**
	 * @throws FileNotFoundException
	 *             if FileOutputStream cannot find file
	 * @throws UnsupportedEncodingException
	 *             if encoding type in OutputStreamWriter is invalid
	 * 
	 */
	public static void saveListToTextFile(Object[] objects, String filename, boolean append, Charset encoding)
			throws FileNotFoundException, UnsupportedEncodingException {

		PrintWriter outputFile = null;

		try {
			FileOutputStream f = new FileOutputStream(filename, append);
			OutputStreamWriter out = new OutputStreamWriter(f, encoding);

			// decorators
			outputFile = new PrintWriter(new BufferedWriter(out));

			// transfer data to file
			for (Object i : objects)
				if (i != null)
					outputFile.println(i);
		} catch (FileNotFoundException e) {
			// e.g., the dir does not exist
			// catch to give a better exception message
			throw new FileNotFoundException("Error saving list. Unable to access device " + filename);
		} finally {
			if (outputFile != null) // successfully opened
				outputFile.close(); // flushes buffer releases resources
		}
	}

	/**
	 * @throws FileNotFoundException,
	 *             UnsupportedEncodingException
	 */
	public static void saveListToTextFile(Object[] objects, String filename)
			throws FileNotFoundException, UnsupportedEncodingException {
		saveListToTextFile(objects, filename, false, Charset.defaultCharset());
	}

	/**
	 * @throws FileNotFoundException,
	 *             UnsupportedEncodingException
	 */
	public static void saveListToTextFile(Object[] o, String fn, boolean append)
			throws FileNotFoundException, UnsupportedEncodingException {
		saveListToTextFile(o, fn, append, Charset.defaultCharset());
	}

	/*
	 * Sorts a list of objects in the given order.
	 * 
	 * Precondition: Assumes that the list is not null and that the list's
	 * capacity is equal to the list's size.
	 * 
	 * 
	 * @param list A list of objects. Assumes that the list's capacity is equal
	 * to the list's size.
	 * 
	 * @param sortOrder A Comparator object that defines the sort order
	 * 
	 * 
	 * @throws IllegalArgumentException if the parameter is * not full to
	 * capacity.
	 * 
	 * @throws NullPointerException if the list or sortOrder * are null.
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void sort(Comparable[] list, Comparator sortOrder)
			throws IllegalArgumentException, NullPointerException {

		Arrays.sort(list, sortOrder);
	}

}
