package group3.util;

public class CopyOfTest {

	public static void main(String[] args) {
		// Create copy of a Person object.
		

	}

}
