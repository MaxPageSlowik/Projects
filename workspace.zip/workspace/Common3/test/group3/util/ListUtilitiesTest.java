/**
 * 
 */
package group3.util;

/**
 * @author Max
 *
 */
public class ListUtilitiesTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		

	}

}
